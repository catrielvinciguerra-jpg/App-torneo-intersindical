# JUBU 2026 · Instalación del sistema (Apps Script + Sheets)

Cuenta: **comunidad@undelta.edu.ar**. Tiempo estimado: 20 minutos. No hace falta programar: solo copiar, pegar y hacer clic.

Archivos que vas a usar: `Code.gs`, `Portal.html`, `Admin.html`. El video y los logos ya van dentro de Portal.html.

> Si ya lo instalaste antes: reemplazá el contenido de los 3 archivos, ejecutá **setup** otra vez (agrega hojas, columnas, el ícono JUBU y programa el recordatorio de cierre, sin borrar nada; aceptá los permisos nuevos que pida Google) y publicá una **nueva versión** (punto 7).

---

## 0. Verificación previa (5 minutos)

1. Entrar a **script.google.com** con comunidad@undelta.edu.ar.
   - Si aparece "Apps Script está desactivado por tu administrador" → pedir a Sistemas de UNDelta que lo habilite para esa cuenta. Sin esto no se puede seguir.
2. Clic en **Nuevo proyecto**. Si abre el editor, Apps Script está habilitado.
3. El control del acceso público se hace en el paso 5. Si en ese paso **no aparece la opción "Cualquier persona"** (solo "Cualquier persona de undelta.edu.ar"), el administrador de Google Workspace bloqueó la publicación externa. Pedir a Sistemas:
   *Consola de administración → Apps → Google Workspace → Drive y Documentos → Configuración de uso compartido → permitir compartir fuera de undelta.edu.ar* (al menos para la cuenta comunidad@).

> Importante: el acceso tiene que ser **"Cualquier persona"**, no "Cualquier persona de undelta.edu.ar". Los jefes/as de otras universidades no tienen cuenta undelta.edu.ar y no podrían entrar.

---

## 1. Crear el proyecto

1. En el editor nuevo, arriba a la izquierda, cambiar "Proyecto sin título" por **JUBU 2026**.
2. Archivo `Código.gs`: borrar todo lo que tiene, pegar el contenido completo de **Code.gs** y guardar (ícono de disquete o Ctrl+S).

## 2. Agregar las dos páginas

1. Botón **+** al lado de "Archivos" → **HTML** → nombre: `Portal` (sin ".html"). Borrar lo que trae, pegar el contenido completo de **Portal.html**, guardar.
   - Es un archivo largo (≈1 MB: logos y video incluidos). Abrirlo con el Bloc de notas, Ctrl+A, Ctrl+C, y pegar. Esperar a que termine de pegar antes de guardar.
2. Repetir con **+** → **HTML** → nombre: `Admin`. Pegar **Admin.html**, guardar.

Tienen que quedar exactamente: `Código.gs`, `Portal.html`, `Admin.html`.

## 3. Instalar la base de datos

1. Arriba, en el desplegable de funciones, elegir **setup** → **Ejecutar**.
2. Google pide permisos: **Revisar permisos** → elegir comunidad@undelta.edu.ar → **Permitir** (si aparece "Google no verificó esta app": *Configuración avanzada → Ir a JUBU 2026*).
3. Al terminar, el registro muestra el link a la planilla **"JUBU 2026 · Base de inscripción"** y a la carpeta **"JUBU 2026 · Sistema"** en tu Drive.
4. Elegir **verificar** → **Ejecutar**. Tiene que decir "Planilla: OK" y mostrar la cuota de mails del día.

## 4. Publicar

1. **Implementar** (arriba a la derecha) → **Nueva implementación** → engranaje → **Aplicación web**.
2. Descripción: `v1`.
3. **Ejecutar como:** *Yo (comunidad@undelta.edu.ar)*.
4. **Quién tiene acceso:** *Cualquier persona*.
5. **Implementar** → copiar la **URL de la aplicación web**.
   - Portal público: `URL` (termina en `/exec`)
   - Portal de organización: la misma URL agregando `?p=admin` al final. Ejemplo: `https://script.google.com/a/macros/undelta.edu.ar/s/XXXX/exec?p=admin`

## 5. Configurar en la planilla

| Hoja | Qué tocar |
|---|---|
| **General** | `ADMIN_PIN` (PIN general), `CIERRE` (por defecto 2026-10-14 23:59), `INSCRIPCION_ABIERTA` SI/NO, `DNI_REPETIDO`, `CRONOGRAMA_ESTADO` |
| **Disciplinas** | mín./máx., ramas (separadas por coma), tipo (`equipo` / `individual`), **pin_mesa** de cada disciplina para entregar a cada mesa |
| **Cronograma** | una fila por actividad: hora + actividad. Se publica solo en la pestaña Fixture |
| **Circulares** | una fila por circular o reglamento: título, subtítulo, estado (`Publicado` / `Próximamente`), link (PDF en Drive compartido como *Cualquier persona con el enlace*), texto. Aparecen en la pestaña Circulares debajo del Boletín 1, en el orden de las filas |

Lo que se carga en la planilla impacta en el portal en menos de un minuto. No renombrar hojas ni columnas.

## 6. Prueba antes de difundir

1. Abrir la URL desde un celular sin sesión de Google (ventana privada).
2. Inscribir una delegación de prueba con un mail propio → llega el mail de "Inscripción recibida". Validarla y enviarla desde la pestaña Validación → llega el mail con listas y acreditaciones. Los deportistas no reciben mail.
3. "Ya inscribí mi delegación": entrar con el email del jefe/a y su DNI como contraseña, y sumar otra lista.
4. Abrir `URL?p=admin`, entrar con el PIN de la mesa, buscar la lista por código o QR, dar presente, generar fixture y cargar un resultado.
5. Borrar las filas de prueba en la planilla (hojas Delegaciones, Listas, Participantes, Partidos, Podios).

## 7. Cambios futuros

Cada vez que se cambie el código: **Implementar → Gestionar implementaciones → lápiz → Versión: Nueva versión → Implementar**. La URL no cambia.

---

## Operación durante la inscripción

- **Panel de inscriptos:** `URL?p=admin` con el **PIN general** → pestaña *Inscriptos*: totales, cuadro por disciplina (clic filtra), buscador por institución/nombre/DNI/mail, detalle de cada delegación con sus listas, botón para reenviar el mail al jefe/a, descarga CSV y acceso a la planilla. Se actualiza solo cada minuto.
- **Mails pendientes:** si se agotó la cuota diaria, la delegación queda con `PENDIENTE` (hoja Delegaciones, columna mail_jefe, y en el panel). Reenviar desde el panel o con la función **reenviarPendientes** → Ejecutar.
- **Correcciones de datos:** se editan directamente en la planilla (hojas Listas y Participantes).
- **Cerrar inscripción:** `INSCRIPCION_ABIERTA` = NO en la hoja General.
- **Drive organizado por deporte:** *JUBU 2026 · Sistema / Deportes / <Deporte> /*
  - una carpeta por universidad, con su lista de buena fe (QR) y las acreditaciones de sus deportistas;
  - la planilla **"Inscriptos · <Deporte> · JUBU 2026"** con todos los inscriptos del deporte (se actualiza sola con cada inscripción y con cada presentismo; se descarga como Excel desde *Archivo → Descargar → Microsoft Excel*).
  - Las acreditaciones de los jefes/as quedan en *JUBU 2026 · Sistema / Jefes de delegación*.
  - Si se corrigen datos a mano en la planilla principal: función **regenerarPlanillasDeporte** → Ejecutar.

## Validación y envío de acreditaciones (PIN general)

1. Al inscribirse, el jefe/a recibe solo un mail de **"Inscripción recibida"** (sin adjuntos). En el portal ve sus disciplinas como *Pendiente de validación*.
2. En `URL?p=admin` → pestaña **Validación**: abrís cada delegación, corregís errores de tipeo (jefe/a y deportistas) → **Guardar correcciones**.
3. **Validar**: tu navegador genera las listas de buena fe (QR) y las acreditaciones con los datos corregidos y las guarda en Drive. Se ven en miniatura para revisarlas.
4. **Enviar al jefe/a** (o **Enviar a todas las validadas**): le llega un mail con todas las acreditaciones y listas completas. En el portal ya puede verlas y descargarlas.
5. Si después se corrige algo o el jefe/a suma una disciplina, la delegación vuelve a *Pendiente*: validar y enviar de nuevo (el mail sale completo).

**Códigos:** la delegación usa la sigla de la institución (campo "Sigla" del formulario; si se deja vacío, las iniciales). Ej.: `UNDELTA`. Cada lista suma el deporte y la rama: `UNDELTA-B3X3-F`, `UNDELTA-BMX`, `UNDELTA-AJD`. Si se repite, se agrega un número (`UNDELTA-B3X3-F-2`).

## Dashboard e informe (PIN general)

- Pestaña **Dashboard**: inscriptos, instituciones, presentismo, edad promedio, género, franjas etarias, condición, localidad de residencia, universidades, disciplinas y medallero. Se filtra por disciplina.
- **Generar informe (Google Docs):** crea en *JUBU 2026 · Sistema / Informes* un documento editable con tablas cuantitativas y un análisis cualitativo redactado a partir de los datos. La sección final "Consideraciones de la organización" queda para completar a mano. Se descarga como Word o PDF.

## Panel de mesas fuera de Google (cámara en vivo) — recomendado para el día del evento

Dentro de Google la cámara solo saca fotos. Publicando el mismo `Admin.html` como página propia, la cámara lee el QR **en vivo**.

1. Verificá que la web app tenga acceso **"Cualquier persona"**: abrí el link `/exec` en una ventana de incógnito; si pide iniciar sesión, cambialo en *Implementar → Gestionar implementaciones*.
2. Creá una carpeta en tu computadora, copiá `Admin.html` adentro y renombralo **`index.html`**.
3. Entrá a **app.netlify.com/drop** (cuenta gratuita), arrastrá esa carpeta y esperá el link `https://….netlify.app`. Podés cambiarle el nombre en la configuración del sitio (ej.: `jubu-mesas.netlify.app`).
4. Pegá ese link en la planilla, hoja **General**, clave **PANEL_MESAS_URL**. Desde ahí, los links de mesa del tablero usan ese panel.
5. El panel ya viene conectado al sistema. Si algún día publicás con *Nueva implementación* (link nuevo), actualizalo en el panel: *Conexión con el sistema*, debajo del PIN.

## Links útiles

- **Link de cada mesa:** tablero (PIN general) → *Links de mesa* → **Copiar** o **WhatsApp** (manda link + PIN). El link abre directo en la disciplina: `…?d=Ajedrez`.
- **Pantalla para TV / proyector:** `URL?p=tv` (link del portal + `?p=tv`). Rota medallero, resultados, próximos partidos, rankings, podios y cronograma; se actualiza solo cada 30 segundos.

## Cierre y recordatorio

- **Cerrar / reabrir inscripción** y **cambiar la fecha de cierre**: tablero → tarjeta *Inscripción*.
- **Recordatorio automático:** 48 h antes del cierre, cada jefe/a recibe un mail con lo cargado. Se programa al ejecutar `setup` y al cambiar la fecha. Se apaga con `RECORDATORIO` = NO en la hoja General.

## Validación: ayudas

- Cada delegación muestra **⚠ posibles errores**: mails mal escritos, nombre igual al apellido, DNI que no coincide con la edad, 18 años justos, mismo deportista en otra disciplina (revisar horarios).
- Las acreditaciones y listas se generan como **imágenes (JPG)** para mostrar en el celular; si alguien quiere imprimir, imprime el JPG. No se genera PDF.

## Para los jefes/as (automático)

- La carga se guarda sola en el navegador: si se cierra la pestaña o se corta internet, al volver aparece **"Recuperar"**.
- Cada ficha marca **✓ completa** y avisa el error al salir de cada campo. Nombres en minúscula o mayúscula se corrigen solos ("juan pablo" → "Juan Pablo") y se sugiere el mail correcto (gmial.com → gmail.com).

## Operación el día del evento (mesas)

1. Cada mesa abre su link (Dashboard → Links de mesa) e ingresa con el PIN de su disciplina.
2. Arriba siempre está la **barra de avance** de la disciplina y rama: *Presentismo → Fixture/Puntajes → Resultados → Podio*, con el **siguiente paso** escrito. Tocando cada casilla se va a esa pantalla.
3. **Presentismo**
   - QR de una **acreditación**: el/la deportista queda presente al instante (botón *Deshacer* por si fue un error). Con la cámara en vivo, se reabre sola para el siguiente.
   - QR de una **lista de buena fe**: se abre la lista, se tildan los presentes y se confirma.
   - La lista queda habilitada cuando alcanza el mínimo de la disciplina.
4. **Resultados** — cada disciplina muestra solo la herramienta que corresponde:
   - **Por enfrentamientos** (deportes de equipo, ajedrez, rap, breaking): los cruces de la llave aparecen ya armados con los presentes → revisar → *Crear llave*. Se carga cada resultado y el ganador avanza solo. Si hay empate en la llave, aparece "¿quién pasa?". Con **grupos**, al terminar todos los partidos aparece *Armar llave final* (1.º y 2.º de cada grupo, cruzados).
   - **Por puntaje o tiempo** (BMX, skate, roller, quad, parkour, fútbol freestyle): se cargan los puntajes de la ronda **Final** → *Guardar puntajes*. Si hay clasificación: cargarla como ronda "Clasificación" y tocar *Pasan a la Final los mejores N*.
   - El formato se puede cambiar en *Formato* (arriba de Resultados) si una disciplina se define distinto.
5. **Podio y medallero se publican solos** al cargar la final (llave), al terminar todos los partidos (todos contra todos) o al guardar la ronda Final (puntajes). La pestaña **Podio** queda solo para correcciones.
6. El PIN general habilita todas las disciplinas. En el **Dashboard** se ven las tareas pendientes (delegaciones para validar, sin enviar o corregidas que hay que reenviar) y el avance del torneo por disciplina.

### Reglas del fixture (para no romper una llave)
- Una llave sin resultados se reemplaza si se vuelve a crear; con resultados no se duplica (para otra llave, usar otro nombre: "Copa de plata").
- Los libres se reparten solos: nadie pasa dos rondas sin jugar.
- No se puede cambiar quién ganó un partido si el siguiente ya tiene resultado: primero se borra el resultado del siguiente.
- Un partido de llave no se borra suelto; "Borrar los que no tienen resultado" no toca una llave que ya empezó.
- Si se borra el resultado de la final, el podio se retira hasta volver a cargarla.
- Grupos: mínimo 2 por grupo, tamaños parejos y sin dos equipos de la misma institución en el mismo grupo (si alcanza la cantidad de grupos). La llave final se arma sembrada: 1.º contra 2.º y sin repetir grupo en el primer cruce.
- Ajedrez (todos contra todos o grupos): la tabla suma puntos de partida (1, ½, 0).

### Validación (PIN general)
- *Validar y enviar al jefe/a* hace todo en un paso. Siguen disponibles *Validar* y *Enviar* por separado.
- Si se corrige una delegación ya enviada, queda marcada **"Corregida · reenviar"** y aparece en los pendientes del Dashboard.

### Versión 19 — Viandas, equipo de organización y alta manual
**Instalar:** reemplazar **Code.gs**, **Portal.html** y **Admin.html** → ejecutar **setup** una vez (crea las hojas *Viandas* y *Organizacion* y el PIN del puesto de viandas, clave **VIANDAS_PIN** en la hoja General) → *Implementar → Gestionar implementaciones → lápiz → Nueva versión*. Si usás el panel en Netlify, subir también Admin.html. El panel muestra "v19".

**Puesto de viandas**
- Link y PIN: Dashboard → Links de mesa → **Puesto de viandas** (Copiar o WhatsApp). Con ese PIN el panel muestra solo la pantalla de viandas.
- Se escanea la **acreditación** de quien retira: ✓ verde *Vianda entregada* (con Deshacer), ✗ rojo *Ya retiró a las HH:MM*, o *Sin presentismo* (al deportista se le entrega solo si ya pasó por la mesa de su disciplina).
- Jefes/as y organización retiran con su acreditación (no necesitan presentismo).
- QR de la **lista de buena fe**: aparece el equipo con los presentes que todavía no retiraron ya tildados → *Entregar viandas a los tildados*.
- Arriba, contadores en vivo y últimas entregas. Con el PIN general también se puede entregar (pestaña *Viandas*). Registro completo en la hoja *Viandas*.

**Equipo de organización (pestaña Equipo)**
- Cada mesa carga a su equipo (solo en su disciplina); el PIN general carga en cualquier disciplina y en *Coordinación*.
- Datos: área, función, nombre, apellido, DNI o pasaporte, celular y email. Al guardar se genera la **acreditación naranja con QR**, se guarda en Drive (*Organización / área*) y se manda por mail.
- Botones por integrante: Descargar, Reenviar, Editar (al editar se reenvía) y Quitar. Registro en la hoja *Organizacion*.

**Alta manual desde Validación (PIN general)**
- En cada lista: **+ Agregar deportista** (hasta el máximo de la disciplina). Para reemplazar a alguien: corregir sus datos, o Quitar y después Agregar.
- Al pie de cada delegación: **+ Agregar disciplina a esta delegación** (con el mínimo de personas de esa disciplina; "+ Otra persona" hasta el máximo).
- Funciona aunque la inscripción esté cerrada y no manda el mail de "inscripción recibida". Lo agregado queda pendiente: **Validar lo nuevo → Enviar lo nuevo al jefe/a**.

### Versión 18
- **Acreditaciones:** abajo van los logos de las instituciones (la misma imagen del recuadro de logos del portal) en lugar de los íconos de deportes. La línea de evento dice solo "Sábado 17/10".
- Se actualizan **Portal.html** y **Admin.html** (Code.gs no cambia). Nueva versión de la implementación. El panel muestra "v18".
- Las acreditaciones ya enviadas no cambian; para regenerarlas: Validación → delegación → "Volver a generar" y reenviar.
- **Cronograma:** se edita en la hoja *Cronograma* (columnas hora y actividad). El texto inicial del código solo se usa si la hoja está vacía.

### Versión 17
Reemplazá **Code.gs**, **Portal.html** y **Admin.html** → Nueva versión de la implementación (y Admin.html en Netlify si lo usás). No hace falta setup.
- Botón **"Confirmar envío"** (antes "Finalizar inscripción"), en el formulario y en la ventana de confirmación, con el aviso de que se puede seguir sumando disciplinas.
- Logos institucionales actualizados al pie del portal. Las acreditaciones siguen con los íconos de los deportes.
- Mail de validación: aclara que se envían las acreditaciones validadas **hasta el momento** y que se puede seguir cargando.
- Panel → Dashboard → **Medir velocidad**: prueba en vivo el tiempo de respuesta (solo lee datos).
- **Cronograma:** se lee de la hoja *Cronograma* de la planilla. Para dejarlo provisorio: dejar solo las filas de las 09:00 y agregar una fila con hora `Resto de la jornada` y actividad `Próximamente`. Se ve en el portal en 1 minuto.

### Versión 16: cargar la delegación desde Excel
Reemplazá solo **Portal.html** → Nueva versión de la implementación. No hace falta setup.

- **Planilla modelo** (`Plantilla_inscripcion_JUBU_2026.xlsx`): una pestaña por disciplina, con listas desplegables (rama, condición, género) y una pestaña de instrucciones. La organización la envía a los jefes/as; también se descarga desde el portal con el botón **"Descargar planilla modelo"**.
- En el portal, paso 2: **"Cargar desde Excel"**. El sistema lee cada pestaña, arma las listas en el formulario y marca en rojo lo que haya que corregir. El jefe/a revisa y envía con el botón de siempre.
- Reconoce la disciplina por el título dentro de la pestaña (aunque la renombren). Ignora pestañas vacías y avisa las que no reconoce.
- Básquet, Cestoball y Beisbol: la columna **Equipo** (1, 2…) separa varios equipos de la misma rama.
- Acepta DNI con puntos, pasaporte, fechas en cualquier formato (dd/mm/aaaa, aaaa-mm-dd o fecha de Excel) y abreviaturas en género (F, M) y condición.
- La carga a mano sigue igual; se pueden combinar las dos.
- Si cambian mínimos, máximos o ramas en la hoja Disciplinas, la planilla modelo sigue funcionando (el control de cupos lo hace el portal con la configuración vigente); para que la pestaña de instrucciones muestre los números nuevos, pedir una planilla actualizada.

### Actualizar a la versión 15 (validar y enviar solo lo nuevo)
1. Reemplazá **Code.gs** y **Admin.html** → **Nueva versión** de la implementación (y Admin.html en Netlify si lo usás).
2. Ejecutá **setup** una vez (agrega la columna *enviada* en Listas; no borra nada).

**Qué cambia:**
- **Sin PDF:** las acreditaciones y listas van solo como imágenes JPG (uso en celular; si alguien quiere, imprime el JPG). Validar es más rápido y el mail más liviano.
- **Validar lo nuevo:** si una delegación ya validada suma una disciplina, el botón dice *"Validar lo nuevo (1 disciplina)"* y genera solo esas imágenes. Lo ya validado no se toca.
- **Enviar lo nuevo:** el mail al jefe/a lleva solo las listas y acreditaciones nuevas, con el texto "las anteriores ya las tenés". Si no hay nada nuevo, el botón dice *"Reenviar todo"*.
- **Correcciones:** si se corrige a un deportista, solo esa disciplina vuelve a validarse y enviarse. Si se corrige el jefe/a o la institución, se rehace todo (aparece en todas las imágenes).

### Actualizar a la versión 14 (blindaje del día de competencia)
1. Reemplazá **Code.gs** y **Admin.html** (Portal.html y Video.html no cambian si ya tenés la v13).
2. **Implementar → Gestionar implementaciones → lápiz → Nueva versión.** Si usás el panel en Netlify, subí también Admin.html.
3. No hace falta ejecutar setup. Las mesas tienen que volver a ingresar una vez con su PIN (cambió el tipo de sesión).

**Qué cambia:**
- **Ingreso:** solo bloquean los PIN incorrectos (10 seguidos → 5 minutos de espera). Los ingresos correctos nunca bloquean.
- **Sesión de 14 h:** la mesa ingresa a la mañana y no le vuelve a pedir el PIN en el día. Si se filtra un PIN: cambialo en la planilla y ejecutá **cerrarSesiones** desde el editor (todas las mesas vuelven a ingresar).
- **Resultados públicos:** se comprimen y nunca fallan por tamaño. Se actualizan en cuanto la mesa guarda.
- **Medallero sin parpadeos:** las hojas se reescriben en un solo paso.
- **"No se guardó":** si una acción falla por conexión o carga, el panel reintenta solo a los 3 s; si sigue fallando aparece un aviso rojo fijo con **Reintentar**. Si la mesa intenta cerrar la página con algo sin guardar, el navegador avisa.
- **Ajedrez · sistema suizo:** Resultados → Armá tu fixture → **Suizo**. Se elige la cantidad de rondas (sugerido: 3 hasta 8 jugadores, 4 hasta 16, 5 hasta 32, 6 si son más) → **Generar ronda 1** → se cargan los resultados (1, ½, 0) → **Generar ronda siguiente**. Nadie repite rival; si son impares uno descansa y suma 1 punto (nunca dos veces la misma persona). Tabla en vivo con puntos y desempate (Buchholz). Al terminar la última ronda, el podio se publica solo.
- **Todos contra todos grande:** si serían más de 60 partidos, el panel avisa y sugiere Suizo o Grupos.

## PROTOCOLO DEL DÍA (imprimir y repartir a cada mesa)

**Antes (16/10)**
- Simulacro: cada mesa ingresa con su PIN, escanea una lista de prueba y carga un resultado. Después se borran los datos de prueba.
- Imprimir por mesa: la **planilla de inscriptos de su deporte** (Drive → Deportes → su deporte) y las **listas de buena fe**. Es el plan B.
- Celular cargado + batería externa. Router o celular con datos dedicado a las mesas.
- Grupo de WhatsApp de mesas + una persona referente técnica.

**Inicio (8:30–10:15)**
- Ingresar con el PIN **una sola vez** a las 8:30 y no cerrar la pestaña.
- Presentismo con el **QR de la lista** o tocando la lista y tildando a mano. El QR de la acreditación individual queda solo para quien llega tarde.
- Si el sistema tarda más de 5 minutos: **la competencia arranca igual** con el papel y se carga después.

**Si algo falla**
| Qué se ve | Qué hacer |
|---|---|
| "Sistema ocupado" o aviso rojo "No se guardó" | Tocar **Reintentar** a los 10 segundos. No escanear de nuevo ni cargar de cero. |
| "Sesión vencida" | Volver a ingresar con el PIN de la mesa. |
| Pantalla en blanco o no carga | Recargar la página. Probar otra red (datos ↔ wifi). |
| Nada funciona por más de 5 minutos | **Plan B en papel:** presentismo y resultados en la planilla impresa, anotando la hora. Avisar al referente técnico. |
| Vuelve el sistema | Cargar lo del papel. Podio y medallero se arman solos al cargar los resultados. |

### Actualizar a la versión 13 (rápida)
1. En el editor de Apps Script reemplazá **Code.gs**, **Portal.html** y **Admin.html**.
2. Archivo nuevo: **+ → HTML**, nombre `Video` (queda `Video.html`). Borrá todo su contenido y pegá el contenido de Video.html. Es el video de presentación: ahora se carga aparte para que el portal abra rápido.
3. Ejecutá **setup** una vez. Crea las hojas *Instituciones* y *Correcciones*, agrega *MAIL_ORGANIZACION* en General y programa el activador que actualiza las planillas por deporte **cada 1 minuto** (solo trabaja si hubo cambios). Google puede pedir permiso de nuevo: aceptá.
4. **Implementar → Gestionar implementaciones → lápiz → Nueva versión.** Si usás el panel en Netlify, subí también Admin.html.
5. Revisá la hoja **Instituciones**: es la lista del desplegable (nombre y sigla). Agregá o corregí las que falten. Si alguien escribe la sigla o el nombre con otra forma ("unsam", "U.N.S.A.M."), el sistema lo pasa al nombre de la lista.

### Cambios de esta versión
- **Velocidad:** inscripción ~4 s (antes ~15 s), presentismo y resultados ~1,5–2 s con una sola espera, portal 284 KB (antes 1,1 MB).
- **Planillas por deporte:** se actualizan en segundo plano (hasta 1 minuto de demora). La planilla principal es siempre al instante.
- **DNI o pasaporte** (6 a 12 letras y números) para deportistas y jefes/as. El pasaporte también sirve para ingresar.
- **Un solo jefe/a por institución:** si otra persona intenta abrir una segunda delegación de la misma institución, el sistema la rechaza y le indica quién es el jefe/a.
- **Disciplinas agregadas después del envío:** la delegación queda "Corregida · reenviar" para validarla y reenviarla.
- **Envío repetido** (se cortó internet y se apretó otra vez): muestra la delegación ya creada, sin duplicar.
- **Pedir corrección:** el jefe/a lo pide desde "Mi delegación"; llega por mail a MAIL_ORGANIZACION y aparece en el Dashboard y en Validación con "Marcar resuelto".
- **Borrador** de la carga: se borra al enviar y vence a las 48 h.
- Delegaciones cargadas antes con el nombre escrito distinto: se corrigen desde Validación (campo Institución).

## Límites a tener en cuenta

- Cuota de mails de Google Workspace: ~1.500 por día. Cada carga de listas consume 1 mail (al jefe/a).
- Si la cámara no abre dentro del portal de organización (depende del navegador), usar "Foto del QR" o el código escrito: funcionan siempre.
