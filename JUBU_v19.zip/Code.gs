/**
 * JUBU San Fernando 2026 — Backend
 * Google Apps Script + Google Sheets · cuenta comunidad@undelta.edu.ar
 *
 * Archivos del proyecto: Code.gs (este), Portal.html (portal público), Admin.html (organización).
 * Primer uso: ejecutar setup() una vez desde el editor.
 */

const TZ = 'America/Argentina/Buenos_Aires';
const PROP = PropertiesService.getScriptProperties();

const HOJAS = {
  General:       ['clave', 'valor', 'nota'],
  Disciplinas:   ['disciplina', 'min', 'max', 'ramas', 'tipo', 'pin_mesa', 'formato'],
  Delegaciones:  ['cod', 'fecha', 'institucion', 'jefe_nombre', 'jefe_apellido', 'jefe_dni', 'jefe_nac', 'cargo', 'celular', 'email', 'jefe_id', 'mail_jefe', 'sigla'],
  Listas:        ['id', 'cod', 'fecha', 'institucion', 'disciplina', 'rama', 'cantidad', 'presente', 'hora_presente', 'mesa', 'validada', 'enviada'],
  Participantes: ['id', 'lista', 'cod', 'institucion', 'disciplina', 'rama', 'nombre', 'apellido', 'dni', 'nac', 'email', 'condicion', 'presente', 'mail', 'genero', 'localidad'],
  Partidos:      ['id', 'disciplina', 'rama', 'fase', 'hora', 'lista_a', 'equipo_a', 'lista_b', 'equipo_b', 'tanto_a', 'tanto_b', 'estado', 'origen_a', 'origen_b', 'desempate'],
  Puntajes:      ['disciplina', 'rama', 'ronda', 'orden', 'participante', 'nombre', 'institucion', 'puntaje'],
  Podios:        ['disciplina', 'rama', 'puesto', 'lista', 'participante', 'institucion', 'nombre'],
  Cronograma:    ['hora', 'actividad'],
  Circulares:    ['titulo', 'subtitulo', 'estado', 'link', 'texto'],
  Log:           ['fecha', 'accion', 'detalle'],
  Instituciones: ['nombre', 'sigla'],
  Correcciones:  ['fecha', 'cod', 'institucion', 'jefe', 'email', 'texto', 'estado'],
  Viandas:       ['fecha', 'id', 'tipo', 'nombre', 'institucion', 'disciplina', 'puesto'],
  Organizacion:  ['id', 'fecha', 'disciplina', 'funcion', 'nombre', 'apellido', 'dni', 'email', 'celular', 'mail']
};
const FUNCIONES_ORG = ['Mesa', 'Juez/a', 'Árbitro/a', 'Voluntario/a', 'Coordinación', 'Acreditación', 'Prensa', 'Salud', 'Seguridad', 'Logística', 'Otra'];
/** Lista inicial de instituciones (editable en la hoja Instituciones). Las que no están se aceptan como "otra". */
const INST_INICIAL = [
  ['Universidad Nacional del Delta', 'UNDELTA'], ['Universidad de Buenos Aires', 'UBA'], ['Universidad Nacional de La Plata', 'UNLP'],
  ['Universidad Nacional de San Martín', 'UNSAM'], ['Universidad Nacional de Quilmes', 'UNQ'], ['Universidad Nacional de Luján', 'UNLU'],
  ['Universidad Nacional de General Sarmiento', 'UNGS'], ['Universidad Nacional de Tres de Febrero', 'UNTREF'], ['Universidad Nacional de La Matanza', 'UNLAM'],
  ['Universidad Nacional de Lanús', 'UNLA'], ['Universidad Nacional Arturo Jauretche', 'UNAJ'], ['Universidad Nacional de Avellaneda', 'UNDAV'],
  ['Universidad Nacional de Moreno', 'UNM'], ['Universidad Nacional de José C. Paz', 'UNPAZ'], ['Universidad Nacional de Hurlingham', 'UNAHUR'],
  ['Universidad Nacional del Oeste', 'UNO'], ['Universidad Nacional de San Antonio de Areco', 'UNSADA'],
  ['Universidad Nacional del Noroeste de la Provincia de Buenos Aires', 'UNNOBA'], ['Universidad Nacional del Centro de la Provincia de Buenos Aires', 'UNICEN'],
  ['Universidad Nacional de Mar del Plata', 'UNMDP'], ['Universidad Nacional del Sur', 'UNS'], ['Universidad Tecnológica Nacional', 'UTN'],
  ['Universidad Pedagógica Nacional', 'UNIPE'], ['Universidad Nacional de las Artes', 'UNA'], ['Universidad Nacional Guillermo Brown', 'UNAB'],
  ['Universidad Provincial de Ezeiza', 'UPE'], ['Universidad Provincial del Sudoeste', 'UPSO']
];

const DISC_INICIAL = [
  ['BMX Freestyle', 1, 3, '', 'individual'], ['Skate', 1, 3, '', 'individual'],
  ['Roller Freestyle', 1, 3, '', 'individual'], ['Quad Skate', 1, 3, '', 'individual'],
  ['Parkour', 1, 5, '', 'individual'], ['Breaking', 1, 6, '', 'individual'],
  ['Freestyle Rap', 1, 3, '', 'individual'],
  ['Básquet 3x3', 3, 4, 'Femenino,Masculino', 'equipo'],
  ['Beisbol 5', 6, 8, 'Mixto', 'equipo'],
  ['Cestoball 3x3', 4, 6, 'Femenino,Masculino', 'equipo'],
  ['Ajedrez', 1, 4, '', 'individual'], ['Fútbol Freestyle', 1, 3, '', 'individual']
];

const CONDICIONES = ['Estudiante', 'Docente', 'No docente', 'Graduado/a'];
const GENEROS = ['Femenino', 'Masculino', 'No binario', 'Prefiero no decir'];
const FAVICON_B64 = 'iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAYVUlEQVR42u17eZRU1bX+t/e5t+aeByYxCKjYGA2CMaIITnFAo6jVxnlKnokx+uKQ6DNJdRnzM47Ep8aEnxmEOHU5xMQo0afQTnFGjbQ4IMjcDT3VfIdz9vujqtpGkUhso671Lmv16kVX3XvOd7797fESvuBXvL1dpVpb9TnX/P6U5d39txTzeQ0msYLhwOja8LwFP/7Of86cmbA6OpL+lr5vfdEB6F66lAAg77r16/pz0XwmbZgIHPQ4ZvNoAOjYyve/8AAMboQt32KGbbEhIrAiZkt5//R72/qgmYnEZt9pnjxZUq2t+rMGQMSQQCACgAARgdGahh2AjuSWbemzvpgB+hAoH4M524ayWBffdHurb6QBWhxRSsF4K//7gtMfFgEBkM8OAjX4WwUIUsMEgIgQEcnCJ15qeuHtNbf3FzUUBKJshMhbrZi397WRzxMjCACDh5cBeQBF18vkstmwxawNsaJQYODzZg4iJSqq4QYAABSRImKLiEgxKyawyOfg8I3e7PgJBKXon2vHtqNbMvZBQxP6XJy6+YAACQQ8uLvFwwhA+ebvP+3zYfoCY7agBGVazBo+AKj8b3Drm9Hhs9O8dK4QM8aUliICZkZ/Or8GAGbOGkYT+KDSftZb7+jsFABS9PRuvjYgEEQAZkJ1NND/KWjAB6nPnyHvhdDSIiISHsgX9/c9F0zEELBFwIj66qWVaHX4GEAf/EVAnxEN4m1tNpJJc+bP5n0n7choMloDICHiICE7e8/dnweA9njcDKMJlMCsbJr5szh4oZZ4IpBKJt0b7nhoyhvrey4vFHKGmdlAtBUMoTYafviQfb7SjXhcEdHwMCC/BSjo33j8iUSCZ85MWEQknamk+5P/f88+9z/3+sK+bD5WjnrJGKEQk5n+lV1uvf21FXujpUUSCeFhASAyhPpS/vFpAyAiVM5AKZlMmo6OpN+5Zk3DCW23/OxvLy1btK6nv5nFNyBiEfGCsWo1ImLfFJq069hX1/Ttg2TSYNZiHrZIkOj9zYMAJv40NIDi8TinUilTpq9vK8Llv7t/yivvrj3p7KsWnDBQ0KOLhSwUkwDMIsaHFbTrgvzO/CvPuurChateag7xcaUwYJYZFgAi0cjgiVeAYJhhc4aJRIIXLwZ3dCT9VCqlwwELf+l4csRdTy07Yk1378n3P/PazLwmcosFEEQrZiaAtBGP7KDdVBPbdOvRk/e/YOG6uQXH1F1zzB4vXgugDZDkcADQHI2SzURSqTqUQ9BPSvHWVIpTra2STCYNACMi9sU333ngyq6eMxLzHzsop1FfdFwY3wUT+YqgCMQGYrQWDsaq7aaq0D8umjZqztXZsd/OBWtao6b7XiZy4u3tioj0sDBghxFVOV/rDDOHpXT8MAbyryRD8Xi7SiGF8uK0xcAv73548lNLV7Tuf94v4pmiv0ve8+F7HphEMxEsZhYIi0BrwLJDEVWlSLari1wz99Svz71iub62q0AnwvShoTpwvwDobmqiT5wNVmhfV1eXBihNxM2AgdEGiqnB83WMiLKVusFWKQ5wRzLpp1KlMtrrq1bV33DnI7PXbBo4df7/vDiroGG5jgPRnmHFYjEYIBYRo8WArSAHgiEOsc41xYILjthtwq8zLdNGXLK0d1HW2DsXC3mvMYj+k3duePCXABbPmrXVutjHZUD5vCHRcKBnU96dCGMA0fB8U3/jnx9pApBta2vbUlWI4u3tnGpdOpTi/ONb79nvjVVdJ5191YIjcp6MLLoujOeCAJ+ZmJQigYgRMSBWdjiqAiSoDvLz4+pjtx13+IxnloVGbf/08vVXZVdkDikWBb4zUKiqbwiPCTlt0yZMGIi3y1bpv00mMHNmgonIP+JH179uKWsvrT0hgu8IB159feXeAFauX79eVWRhM0FrbdUMYMGDT45fuOSNow++4JqT+/POlIJn4LkOSIxmfp/iRsSIwLKCIRW2bYTgrx5VE24/YMouD4756l5+x8qeg+a/l253aNOOrsfwiwOGhN1IfVO4XtIP/PKIPX9V6hfQPy3WfnwNmAWgA6ivij2xpj9/lu8IMROKThFretPfswh3zJs3z8fMhIWOpD/ktIMX3vTHQ95e33fKTQ92HJbTiDpOEeJ7wsxaERSIWSBGaw22gxwMhTggfrE+Gnpo9+3q79rn8INX/CONPZ9bO5DIPPvuLBOIwC0Cxs9oJtIibEVq60KNVvHBW4+cekz6rrtVezxuPo5vsrZh/6YDwMFTd370zdVduTwoAhDE98yGgcL0b/7s18kFl52dZCI/GLDxi/n37fr8W2vjB5x/deuA400quD58twgGfCZiKMWQkqCZsqBFLYUoy4tfqovOP3rWtGe7Ro4fsWRV37G3LemZowPhGs8R+EUP7KR9EAlAikORQMwiNNrOz379ldyVP33stUu+tdOMG4got02pzceUbkWplJ598XWp5Zsyx8F3fIAsbYwJhyJcHwm8Hgrana7nTcoU3F0Lmth1HIjxjFIsEHBZUUu2zUqFwhGE2PSNiIXvmjn5S6ndDjqw/6E3ew9d15M+tSjWJB8EL58HifGJIWIMGVJWIBJDkDSilvnr9NHhyxpCkn5olf5rlXIfuHH2lEtnLlpkdey/vz+sAFT6cD+5tX3vhS++9Ux/JqstZgUAxhgDZbGybGjfh2gPTPCJqKLiICKIGG3AKhKtQtTGW+PrwnO/ffxBTyyREROWvLvhzN5M4UgJVim3mIPxPKOYtBghI6JUKEzBUBiWk83XhK27p42J3PjdPUevP+/hd/9jbY5/HBR/4x3x3cdTW5snbW2yNY/0rzEAQDweV/fek9KHX3x9+7ubMnHjFX0ClU1JDAAz5KSpUkNgArTRvgpGrNpwoH9iQ/SS75465/F71+lDV23oPdel4E6ur+EV8mDAJxbRGkyWpYLRGGztIkj+s6Oqwr+97tCxf3lqVS664LXuM/vy/vfzCFbbZLB7Aw5JHvjlRyoHheHUgMrV0tIiKQF/Y68pF9z2+N+/3u0Uq6xSPMwAMQAutabeT5mJAE9rHa2us0ZG7PsunLPbxX/zJx5y3Usbn/RUeESxCBgvrRXDMIhKmlCFsMUI6uLq2oD/xwMmNf0xvuOo1Zc/8c700+5b/puMo4/yA2HkMxkTqQ5hVNCbmzxwj0fi7fKx1P9fZsBgFJdq1d+99nfHv/hu1139/WnPUmRt+X4ivhZTW1endm6M/egH559x99zFyxdkJDCjkMmAjO8TCbSAVSDMwXAQlpNzYgF1X8uoqt/+cPqEl3/76spxL6zKntRb8E7wrfBox/Ph5bMgkaIdqw6NsJyHf3vMHke2plJIxeMGH4P6nwgAoNQk7Ugm/RMSN//0ze50MjvQ71tKKdn8nuJro2tq66yd6qzWr59+eufDr6x+Ou2rGp3P+sRgIwQ7HOGgpRAWd8mo2sC8S/cZ8ZcNDqt5z62fszHjnunA2s0jBSefg/ieZiaIiLajtYFadh9N7B45cqeddnTLBYptisvVvwrAex0dgni7euOWMxYfdFRrQ1/R7F0sFIQJUomdtdEmVlNrTR4Ruyh+9hlPpp5/7+WBoo6Jm9cgMFSAq2JRqg/oh6eNDJ9+7aEtV72wprfmzqU9yYXL+m7uk9Bh2aI3winkxHiuJhEiKuUf4Zp6u8lyH0pO7ZszceI0J5EAd+y//zYnJZ88jy27xpMv/82Fb67bdG1/Ng+C9hkEDoat7WujqYeuveCMb6ZeXdVfNPXQjhEBVDDMtQFZt1Nj+Ky2WTs/ccHfln13Xab4PZdDOziuB69QAEN8kJS1RQQCLaysaDSCUWFzw82zv3wREfmJRILLgRf+/QCUQUAqpX944x0Hv7B8zc0bM8UdC/k8mhtq+5658TsTTr1n+T09OniAn8toEJEKhrguIC/fftzomT99tGvq8rRekKPw2EIuB/FczQSAiEvrMwKwNgIrGK1CjP0NO9SqC688eNc7AFDZvf7L3Zlhq+VU5nCWL19ec9n8hZdtyPnnN1DxkvFHHr/pze7C/MJAX1GxsoyyqT6EjXd+rXH82S9uPLYX4QXpbAHw3XLMUG5tCImIBlipQCSKoHjeiJj1+4NGqrZjp7Wsj7e3q20VvE8VgKHeAQBue/SJnU6dOqbrzMf7Hu3nqj09z4fjuIjFwtg1kv+6p+z+t/vp+f5s3lEwgECJCIGgSFlQgRACihE0Tm9DzL5nclPglnP32vmVUkC2ba7u3wbAYLOitZWRSmkAuK9zTcOSdZnp3dnCwQUT2NeG033rnD0OO/WeF7vSdn2TOAUQMwADEgHcAkK2WhMJqJcaYvafD9ix6eHDxjWvr0Si7fG4oU946p8uAEOKH8lkUobWB2wCXCP08NtvB55YWfyG75mxec8Tm22y2BSDoeCK0VWxVd/76vYrhyYz8XZRLXFIksjgi3aJCMXbRc1MLNq2qDPermYuWmSJfLr998+iqUUAJN4uqqVp8WbP79w4S1rikDZAhpPm/3f93/UJTKBig21toGQbZKjfTSQS3Nk5mUpZ4mDRc6v3GVJplqF/K9dJtjjbV46st1pt7uycTIgDLUu3tg6hRKKNOjsnU0tLXJLJL5aZ8cyZCetj6hYNCwOoVNWsvunOR2PCpmniuNoVh3/ta+nyqamb71w4SWDCAGBZZv05xx+5dksnKCKUyWQagSqpqgIByFfcXJkZMQA5APb6TKY6uyGLdzZsgB8xMmn0aNpx1KgBi8nVMiTWKDNIRPi6u/40JqIizRwIkMnles856Yh3t7SfVatWhf/y9LJxpKyIcfN6fP1Ob3wEAAlWfLk59JzLb1nbPTDHLRZCZAVqqkPWwufuvOYwI8Dsc38+Y2137xO+58GIIByw83P222OfH5978iuV5KRSmTnlv+ae+e7anrlOseALyIoG7YFjD54x/fxTDl9z5e/vHPfXx195uqu3Pxu0A3YoaDdoLdBGQ4yBZdswIhtrq2NvTdxuVOrW5Dm3EZGppOOnXDJ371fffu8xrU2YiBAI2IWD9/zyPldddNqSIbEIRCS432mXPtndl50asBWBFCZs1zTvI3xzUhQz8kVn+tru3hGWaGNYwQsH6iufMCLNPf1ZOIW8b4ygrqE+0ldwJgJ4ZXGpiWIqo+yO545e1dVTXcxlRRuhUY211bX1sQgA9A4U7A09A6MzBQ8MD9poMA3prwhArKq7+7IT1nQPHLbfaZeddP/9i46bc8evMgCQK2TtTL4YzmZyGiQmVl0TXtfXsxuAJYsBTiQSJplMmr/8z1PNfenctE19A7AUeaRse1RjdTVvRbTg+yZnKxJWyreVAlvsVSbEtm+uHRUI2LAsBdtWxID4rmyxCsuW7doWS8C2vGDAEoKkm2ORDAAobQkz+STGMEHbisUYAbEFZQVASoHEaCVa5zJpd8WG3gN/+adH/mDdd58GgGisytiKxbaYArZFEJHevnRpHYvfX8PqTTkR0U7AYgkoxRYTIFLDW1MAZuLSXKSUDW5wQg4CcGVcsDyVRVURe4v3E19IBCQiZIwhViriGjcKAAiiMmbEpfiHaMYekzbuP23Si3tPHv/YuFENb4QiYaVFlGUp23cKuqs3c9SFV/1uCgA4foGNgCrrAEAs/CHTDteFQeDSOspb6UvnProoSgQEbYuHzgLQR0qokBgDXyQLfHgqyzf+ECdG0NpY763bVHq28/7njDZSXV2FWXvtduYPT5/zoK99uJ4OfPPi6857fuk7VzvFojCTuMaYN1evnQRgSTadV6Y8IykAmBlVNWEa7GaVr7GNDWRZquz3qDLxGvkoBpAxAq11ulTL34K/FNGDA1PM7HkuVq7r3gCUfPFH+jIiOK4rr731ntkS6QBB59quVwuOC883ICK3dfa+dwUtZaS8EAJxNBQsAkBzQ31dKZskEREoZoxsrB80xWRbmwDAV740os/z/V4uv1hgtEY0GhprfUR1g/2ODtOfzq9jpSC+liEbBwC4vikMdXkigJEtZ2u+b4YSAEaAgmusLQU8vtYoDGSOP/6iq9c5nheFEX3trfd9K1twFDP5nmGrOhLomX3w9GduvwqoikZqS70ZEQJY+x66egbWAEBz5+TBGb7Gxsa8pVR+KJ1d11NbzdCi0RDQn9usR166gSBoW6HBASkRUYqpvi4aA4DOzs7NrIWHWIsYMbYd4HFjGhoBQCt/MMxjIhQKRTz58pvXAARjSjVm13EhxhdiVjttP+K9WdN2OerEg/buAoCC49PgyG55jjufKxZLT0tthm8kHCTTmylNkQugtZGtTolFQ8GPlkhF1pDTN8qy0VRdXVcuDW32Wa1NxYZIAFGWQlBZsZIGBjeTEyJCNptDLptFoZBHIZ+H0Z4QkSEiKMX5TM6tqdw77+QxdGSHAFhqqAjKEPNTH9I5RjyuyuVxBcRVIpEYBEWbjxiVKN2OP0xfNwy8/ypbx+LFFQpM0L4GEYEJ7DgO1m/s7QIAx3E2r9Mzo7460lNTFemqiYW7amPhrqpYRAuxEu2j8921uyx68fXFl1zzuz1Ldf3N1yEAyB7qjd7HwjO+Iar064BgMCgWUimtBveVQjIJtMTjVjyR4EeX5z8UHEj5k07R7X1/apTg+RrregYM4nHV3FlifUtzM3cCZCtlKk8VgCyC1ESipTjAsirCDN/XaGyqxoVnHDU7FKWluX5YdU22fvOtrh3vfeTvqdVdPeODCs6mgVzwhWXL/wvAnHA4TEMCJ01KWZGAPRrxuKqrO4gTiRbp7JzMAAKFvBOrxDisFAqF4hrrG9+/4tpMrrir63o6Go3S5B1GXj73kv949goAM06/dAetNRSBBYBSrKisAWzTeiYCDIgVieN62LRp4BCkUn9KARoAOlMpN2grrOnqmep7HlRZMwIBu+fE+KyNv7gI8K3N3zUiIjiunz71iK9nh/z3y8eed8U13enCLW4hBzFGetP5iQCQyxXXijGAEDGTOK6Prp7+GUil7puH1GDh9PKbbt/dM9IEY4woBhFJIBjos1au23heV1/OthgQHkBfemDMTfMfOPatdd07PPLMK3tA+wJFJICpq4n1Vkxgwg7br3jm5WW+QJiI2PccWbaq66w55/38rdkH7Hn3PjuPzaSe+Me4Z19968Kly1dPJfENSIGVMpFw8NUpO4zrAwBL25sBYAT48sTxEREJlfUTAwMDoUPP+X+HeZ4LImIZzIiASWMaO1964x1fpLwOpygr1naffeIl179x6P57/WlsIOKm/v7c1x548sX/HsjmS3MZRmAHFI2sr33eqquOPrmpP7sfiRh4RbW2y93tV/c8usw3WmVyRShF8H0t0aoY7zCq+fanRNASjwd+ctrR78w4/dI/D+S8Y4zxXMUUyBcK9ivvrL1+2cp1l19PNGCMGZNzfGjPEWZFvq9NrDpmTdh+9G3PffAlMwGUpdA/kMEFV8970FLKM0ZIMUm+6IY29KabxPdARCBmqo1F3wKAtvNPW7HvqZc8kinow0W7rlIUGEhnw8++9s5vlnQuvxqA4xs0Z/MFcCmUNZ4YbowEs4fN2G2+NWWX8Vd192UP6Onth20pzRDTm84qIkARGV8bY4Wi9naNVY/N/8UFd48PpRltbX6SiE6ePf2Cefd2zFjV1dck2tOKFZxiXopCMSKKiTFgJp/A5PlaBSOxwJjG2EO3X/mDO73lf1epcumcCEKAMCDaaCxf3TWy/OZTKeyBQBFpCOAZsZtrI7LH5B2vXARAi/BB03c7r//R56d095lR8F2tFKNYyEsBVENEEGO0UiRaCxlA1dfVYZcJY845c86hq/mGH37rkT0mfekHjQ21vpBSnjYMEYgRaBCHI1FrxzENf7vu3FO/SeWydJLIJBIJ+tZxR7x3zKF7z5w4tvmZcCSqDJEyBpYYI2K0iAiMkEW2rZrqa9O7Txx1w+Lf/fxYItIVV+krj7QRyxeQFmIpzURAKQZBANHCTDDEyg6F1NiRjeu+2jLu6OsuOv2lRCLBiUQCPzn7hOVH7jN5//Fjmp6OxKJKSCkBWcZo0b4vQlAGbIXCYbX96KZ3pn953HHt11y8IB6PK6r09X409w/7vdS54oK+gfR+rq9rLKW8cDDw2vjtR/5xwc//80Yikg8OQlbyfhFRZ7XdfMqKNd3fTGez01zXq/e1pnAw5ChLvd1YV/Xc7H13n3vuiUctrWhdpad3xS3tYxa//I/H+zP5gO/54mmftBYwkxUOBWoVcdDx/PU1VdGVo0Y0/u37rTP/sO/UqeuGNkSHrIO/nbz5hHfXdsf7B7JTiTCmrCsbamKRV8eObHxg/s/Pv4OI0kgkGMmk+V8+n347USXDJAAAAABJRU5ErkJggg==';

/* =====================================================================
   INSTALACIÓN
   ===================================================================== */

function setup() {
  reset_();
  let ss;
  const sid = PROP.getProperty('SHEET_ID');
  if (sid) ss = SpreadsheetApp.openById(sid);
  else { ss = SpreadsheetApp.create('JUBU 2026 · Base de inscripción'); PROP.setProperty('SHEET_ID', ss.getId()); }

  if (!PROP.getProperty('FOLDER_ID')) {
    const f = DriveApp.createFolder('JUBU 2026 · Sistema');
    PROP.setProperty('FOLDER_ID', f.getId());
    PROP.setProperty('IMG_FOLDER_ID', f.createFolder('Imagenes').getId());
    DriveApp.getFileById(ss.getId()).moveTo(f);
  }

  Object.keys(HOJAS).forEach(n => {
    const ex = ss.getSheetByName(n);
    if (ex) {
      const h = HOJAS[n], cur = ex.getRange(1, 1, 1, h.length).getDisplayValues()[0];
      if (cur.join('|') !== h.join('|')) {
        ex.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold').setBackground('#24546b').setFontColor('#ffffff');
        ex.getRange(2, 1, Math.max(1, ex.getMaxRows() - 1), h.length).setNumberFormat('@');
      }
      return;
    }
    const sh = ss.insertSheet(n), h = HOJAS[n];
    sh.getRange(1, 1, 1, h.length).setValues([h]).setFontWeight('bold').setBackground('#24546b').setFontColor('#ffffff');
    sh.setFrozenRows(1);
    if (sh.getMaxRows() < 3000) sh.insertRowsAfter(sh.getMaxRows(), 3000 - sh.getMaxRows());
    sh.getRange(2, 1, sh.getMaxRows() - 1, h.length).setNumberFormat('@');
    if (n === 'General') sh.getRange(2, 1, 9, 3).setValues([
      ['ADMIN_PIN', pin_(6), 'PIN general de organización (todas las disciplinas)'],
      ['INSCRIPCION_ABIERTA', 'SI', 'SI / NO'],
      ['CIERRE', '2026-10-14 23:59', 'Fecha y hora de cierre (AAAA-MM-DD HH:MM)'],
      ['FECHA_EVENTO', '2026-10-17', 'Para validar 18 años'],
      ['DNI_REPETIDO', 'NO_EN_MISMA_DISCIPLINA', 'NO_EN_MISMA_DISCIPLINA o NUNCA'],
      ['NOMBRE_REMITENTE', 'JUBU San Fernando 2026 · UNDelta', ''],
      ['EVENTO_TEXTO', 'Sábado 17/10 · 9:00 hs · Parque del Bicentenario de la Independencia (Beruti y Pasaje Los Pinos, Victoria, San Fernando)', 'Se usa en los mails'],
      ['CRONOGRAMA_ESTADO', 'Provisorio', 'Provisorio / Definitivo (se muestra en el portal)'],
      ['MAIL_CONFIRMACION', 'SI', 'Mail de "inscripción recibida" al jefe/a (sin adjuntos)']
    ]);
    if (n === 'Disciplinas') sh.getRange(2, 1, DISC_INICIAL.length, 6).setValues(DISC_INICIAL.map(d => d.map(String).concat(pin_(4))));
    if (n === 'Instituciones') sh.getRange(2, 1, INST_INICIAL.length, 2).setValues(INST_INICIAL);
    if (n === 'Circulares') sh.getRange(2, 1, 2, 5).setValues([
      ['Reglamento general', 'Normas de competencia por disciplina', 'Próximamente', '', ''],
      ['Boletín 2', 'Cronograma y fixture', 'Próximamente', '', '']
    ]);
    if (n === 'Cronograma') {
      const c = [['09:00', 'Acreditación'], ['09:00', 'Ceremonia de apertura'], ['Resto de la jornada', 'Próximamente']];
      sh.getRange(2, 1, c.length, 2).setValues(c);
    }
  });
  ['Hoja 1', 'Sheet1', 'Hoja1'].forEach(n => { const s = ss.getSheetByName(n); if (s && ss.getSheets().length > 1) ss.deleteSheet(s); });
  try {
    if (!PROP.getProperty('FAVICON_URL')) {
      const f = DriveApp.getFolderById(PROP.getProperty('FOLDER_ID')).createFile(Utilities.newBlob(Utilities.base64Decode(FAVICON_B64), 'image/png', 'favicon-jubu.png'));
      f.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
      PROP.setProperty('FAVICON_URL', 'https://drive.google.com/uc?id=' + f.getId() + '&export=download&format=png');
    }
  } catch (e) { Logger.log('Favicon: no se pudo compartir públicamente (' + e.message + ')'); }

  ['RECORDATORIO|SI|Mail a jefes/as 48 h antes del cierre', 'PANEL_MESAS_URL||Link del panel de mesas publicado fuera de Google (cámara en vivo)', 'MAIL_ORGANIZACION||Mail que recibe los pedidos de corrección (vacío = la cuenta del sistema)'].forEach(x => {
    const [k, v, nota] = x.split('|');
    if (!rows_('General').some(r => r.clave === k)) append_('General', [{ clave: k, valor: v, nota: nota }]);
  });
  if (!rows_('General').some(r => r.clave === 'VIANDAS_PIN')) {
    const usados = new Set(rows_('Disciplinas').map(r => r.pin_mesa).concat(cfg_().ADMIN_PIN || '')); let vp = pin_(4);
    while (usados.has(vp)) vp = pin_(4);
    append_('General', [{ clave: 'VIANDAS_PIN', valor: vp, nota: 'PIN del puesto de viandas (escanea acreditaciones de cualquier disciplina)' }]);
  }
  let rec = '', pl = '';
  try { rec = programarRecordatorio_(); } catch (e) { rec = 'no programado (' + e.message + ')'; }
  try { pl = programarPlanillas_(); } catch (e) { pl = 'no programado (' + e.message + ')'; }
  const msg = 'Recordatorio de cierre: ' + rec + '\nPlanillas por deporte: ' + pl + '\nListo. Planilla: ' + ss.getUrl() + '\nCarpeta: https://drive.google.com/drive/folders/' + PROP.getProperty('FOLDER_ID') +
    '\nPIN general y PIN por mesa: hojas General y Disciplinas.\nCuota de mails disponible hoy: ' + MailApp.getRemainingDailyQuota();
  Logger.log(msg);
  return msg;
}

/** Video de presentación (archivo Video.html del proyecto). El portal lo pide después de mostrarse. */
function apiVideo() { try { return HtmlService.createHtmlOutputFromFile('Video').getContent().trim(); } catch (e) { return ''; } }

/** Verifica permisos y servicios antes de publicar. Ejecutar desde el editor. */
function verificar() {
  const out = [];
  out.push('Cuenta: ' + Session.getEffectiveUser().getEmail());
  out.push('Planilla: ' + (PROP.getProperty('SHEET_ID') ? 'OK' : 'FALTA — ejecutar setup()'));
  out.push('Cuota de mails hoy: ' + MailApp.getRemainingDailyQuota());
  try { out.push('URL web app: ' + (ScriptApp.getService().getUrl() || 'todavía sin implementar')); } catch (e) { out.push('URL web app: sin implementar'); }
  Logger.log(out.join('\n'));
  return out.join('\n');
}

/* =====================================================================
   WEB APP
   ===================================================================== */

function doGet(e) {
  reset_();
  const admin = e && e.parameter && e.parameter.p === 'admin';
  const out = HtmlService.createHtmlOutputFromFile(admin ? 'Admin' : 'Portal')
    .setTitle(admin ? 'JUBU 2026 · Organización' : 'JUBU San Fernando 2026')
    .addMetaTag('viewport', 'width=device-width, initial-scale=1, viewport-fit=cover')
    .setXFrameOptionsMode(HtmlService.XFrameOptionsMode.ALLOWALL);
  const fav = PROP.getProperty('FAVICON_URL');
  if (fav) { try { out.setFaviconUrl(fav); } catch (err) {} }
  return out;
}

/**
 * API JSON para el panel de organización publicado fuera de Google (permite la cámara en vivo).
 * Requiere que la implementación tenga acceso "Cualquier persona". Cada función valida su token/PIN.
 */
function doPost(e) {
  reset_();
  const API = { adminLogin: adminLogin, adminBuscar: adminBuscar, adminPresente: adminPresente, adminDisciplina: adminDisciplina, adminGenerar: adminGenerar,
    adminLlave: adminLlave, adminBorrarPendientes: adminBorrarPendientes, adminPartido: adminPartido, adminResultado: adminResultado, adminBorrarPartido: adminBorrarPartido,
    adminPuntajes: adminPuntajes, adminPodio: adminPodio, adminResumen: adminResumen, adminReenviar: adminReenviar, adminInforme: adminInforme,
    adminDelegacion: adminDelegacion, adminEditar: adminEditar, adminQuitarParticipante: adminQuitarParticipante, adminSubirImagen: adminSubirImagen,
    adminSubirPdf: adminSubirPdf, adminValidar: adminValidar, adminEnviar: adminEnviar, adminEnviarTodas: adminEnviarTodas, adminMesas: adminMesas,
    adminInscripcion: adminInscripcion, adminDeshacerPresente: adminDeshacerPresente, adminFormato: adminFormato, adminPresenteUno: adminPresenteUno, adminClasificar: adminClasificar, adminHacer: adminHacer, adminCorreccion: adminCorreccion, adminSuizo: adminSuizo, adminVianda: adminVianda, adminViandaVarios: adminViandaVarios, adminViandaDeshacer: adminViandaDeshacer, adminViandasResumen: adminViandasResumen,
    adminOrgLista: adminOrgLista, adminOrgGuardar: adminOrgGuardar, adminOrgQuitar: adminOrgQuitar, adminOrgEnviar: adminOrgEnviar, adminAgregarDeportista: adminAgregarDeportista, adminAgregarDisciplina: adminAgregarDisciplina, apiPublico: apiPublico, apiConfig: apiConfig };
  let out;
  try {
    const req = JSON.parse((e && e.postData && e.postData.contents) || '{}');
    if (!Object.prototype.hasOwnProperty.call(API, req.fn)) throw new Error('Función no permitida.');
    out = { ok: true, v: API[req.fn].apply(null, Array.isArray(req.args) ? req.args : []) };
  } catch (err) { out = { ok: false, e: err.message }; }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}


/* =====================================================================
   VIANDAS (puesto central) · v19
   Se escanea la acreditación (o la lista de buena fe) y queda registrada la entrega.
   Deportistas: solo con presentismo tomado. Jefes/as y organización: con acreditación válida.
   ===================================================================== */

function viandaSes_(token) { const s = ses_(token); if (s.rol !== 'viandas' && s.rol !== 'admin') throw new Error('Tu PIN no habilita el puesto de viandas.'); return s; }
/** Quién es el dueño de un código de acreditación. */
function persona_(id) {
  const p = rows_('Participantes').find(x => x.id === id);
  if (p) return { id: id, clase: 'Deportista', nombre: p.nombre + ' ' + p.apellido, inst: p.institucion, disc: p.disciplina + (p.rama ? ' ' + p.rama : ''), presente: p.presente === 'SI' };
  const d = rows_('Delegaciones').find(x => x.jefe_id === id);
  if (d) return { id: id, clase: 'Jefe/a de delegación', nombre: d.jefe_nombre + ' ' + d.jefe_apellido, inst: d.institucion, disc: '', presente: true };
  const o = rows_('Organizacion').find(x => x.id === id);
  if (o) return { id: id, clase: 'Organización', nombre: o.nombre + ' ' + o.apellido, inst: 'Organización', disc: o.disciplina + (o.funcion ? ' · ' + o.funcion : ''), presente: true };
  return null;
}
function viandaInfo_(v) { return { hora: String(v.fecha).slice(11, 16), puesto: v.puesto }; }
function viandaTotal_() { return rows_('Viandas').length; }
function viandasRes_() {
  const v = rows_('Viandas'), ps = rows_('Participantes');
  return { total: v.length, deportistas: v.filter(x => x.tipo === 'Deportista').length, presentes: ps.filter(p => p.presente === 'SI').length,
    jefes: v.filter(x => /^Jefe/.test(x.tipo)).length, org: v.filter(x => x.tipo === 'Organización').length,
    ultimas: v.slice(-8).reverse().map(x => ({ hora: String(x.fecha).slice(11, 16), nombre: x.nombre, detalle: x.tipo === 'Deportista' ? x.disciplina + ' · ' + x.institucion : x.tipo })) };
}
function toks_(texto) { return String(texto || '').trim().toUpperCase().split(/[|\s]+/).map(t => t.trim()).filter(t => t && t !== 'LISTA'); }

function adminVianda(token, texto) {
  reset_();
  const s = viandaSes_(token), toks = toks_(texto);
  if (!toks.length) throw new Error('Código no reconocido.');
  const listas = rows_('Listas');
  for (const t of toks) {
    const l = listas.find(x => x.id === t);
    if (l) {
      const ya = rows_('Viandas'), nombres = equipos_(listas);
      return { tipo: 'lista', total: ya.length, lista: { id: l.id, disc: l.disciplina, rama: l.rama, equipo: nombres[l.id] || l.institucion,
        deps: rows_('Participantes').filter(p => p.lista === l.id).map(p => { const v = ya.find(x => x.id === p.id);
          return { id: p.id, nombre: p.nombre, apellido: p.apellido, presente: p.presente === 'SI', vianda: v ? viandaInfo_(v) : null }; }) } };
    }
    if (persona_(t)) return conLock_(() => Object.assign(entregar_(t, s), { res: viandasRes_() }));
  }
  throw new Error('No se encontró ' + toks[0] + '.');
}
function entregar_(id, s) {
  const q = persona_(id), prev = rows_('Viandas').find(x => x.id === id);
  if (prev) return Object.assign({ tipo: 'ya', total: viandaTotal_() }, q, viandaInfo_(prev));
  if (!q.presente) return Object.assign({ tipo: 'nopres', total: viandaTotal_() }, q);
  append_('Viandas', [{ fecha: ahora_(), id: id, tipo: q.clase, nombre: q.nombre, institucion: q.inst, disciplina: q.disc, puesto: s.rol === 'admin' ? 'Organización' : 'Puesto de viandas' }]);
  log_('vianda', id + ' · ' + q.nombre);
  return Object.assign({ tipo: 'ok', total: viandaTotal_(), hora: ahora_().slice(11, 16) }, q);
}
/** Entrega a varios de una lista de buena fe (solo presentes que todavía no retiraron). */
function adminViandaVarios(token, ids) {
  reset_();
  const s = viandaSes_(token);
  return conLock_(() => {
    const out = { entregadas: 0, ya: 0, sinpres: 0 };
    (ids || []).slice(0, 40).forEach(id => { const r = entregar_(String(id), s); out[r.tipo === 'ok' ? 'entregadas' : r.tipo === 'ya' ? 'ya' : 'sinpres']++; });
    out.total = viandaTotal_(); out.res = viandasRes_();
    return out;
  });
}
function adminViandaDeshacer(token, id) {
  reset_();
  viandaSes_(token);
  return conLock_(() => { const n = remove_('Viandas', x => x.id === id); log_('vianda_deshecha', id); return { quitadas: n, total: viandaTotal_(), res: viandasRes_() }; });
}
function adminViandasResumen(token) {
  reset_();
  viandaSes_(token);
  return viandasRes_();
}

/* =====================================================================
   ACREDITACIONES DE ORGANIZACIÓN · v19
   Cada mesa carga a su equipo (su disciplina); el PIN general carga a todos, también "Coordinación".
   ===================================================================== */

function orgPuede_(s, disc) {
  if (s.rol === 'admin') return disc === 'Coordinación' || s.discs.indexOf(disc) >= 0;
  return s.rol === 'mesa' && s.discs.indexOf(disc) >= 0;
}
function orgInfo_(o) { return { id: o.id, disc: o.disciplina, funcion: o.funcion, nombre: o.nombre, apellido: o.apellido, dni: o.dni, email: o.email, tel: o.celular, mail: o.mail, fecha: o.fecha }; }
function adminOrgLista(token) {
  reset_();
  const s = ses_(token);
  if (s.rol === 'viandas') throw new Error('Tu PIN no habilita esta sección.');
  return { funciones: FUNCIONES_ORG, discs: (s.rol === 'admin' ? ['Coordinación'] : []).concat(s.discs),
    org: rows_('Organizacion').filter(o => orgPuede_(s, o.disciplina)).map(orgInfo_) };
}
function idsUsados_() {
  const u = new Set();
  rows_('Participantes').forEach(r => u.add(r.id)); rows_('Listas').forEach(r => u.add(r.id)); rows_('Organizacion').forEach(r => u.add(r.id));
  rows_('Delegaciones').forEach(r => { u.add(r.cod); u.add(r.jefe_id); });
  return u;
}
/** Alta o edición de un integrante de la organización. o = {id?, disc, funcion, nombre, apellido, dni, email, tel} */
function adminOrgGuardar(token, o) {
  reset_();
  const s = ses_(token);
  o = o || {};
  const x = { disciplina: clean_(o.disc, 60), funcion: FUNCIONES_ORG.indexOf(o.funcion) >= 0 ? o.funcion : 'Otra', nombre: clean_(o.nombre, 60), apellido: clean_(o.apellido, 60),
    dni: dni_(o.dni), email: clean_(o.email, 120).toLowerCase(), celular: clean_(o.tel, 30) };
  if (!orgPuede_(s, x.disciplina)) throw new Error('Tu PIN no habilita cargar organización de ' + (x.disciplina || 'esa área') + '.');
  const err = [];
  if (!x.nombre || !x.apellido) err.push('Falta nombre o apellido.');
  if (!okDoc_(x.dni)) err.push('DNI o pasaporte inválido.');
  if (!okMail_(x.email)) err.push('Email inválido.');
  if (err.length) return { ok: false, errores: err };
  return conLock_(() => {
    const todos = rows_('Organizacion'), id = clean_(o.id, 20).toUpperCase();
    const dup = todos.find(r => r.dni === x.dni && r.id !== id);
    if (dup) return { ok: false, errores: ['Ese DNI ya está cargado en organización (' + dup.disciplina + ', ' + dup.funcion + ').'] };
    if (id) {
      const r = todos.find(z => z.id === id);
      if (!r || !orgPuede_(s, r.disciplina)) throw new Error('Integrante inexistente.');
      update_('Organizacion', r._row, Object.assign({}, x, { mail: '' }));
      log_('org_edicion', id);
      return { ok: true, org: orgInfo_(rows_('Organizacion').find(z => z.id === id)) };
    }
    const nuevo = Object.assign({ id: code_('JUBU26-', 6, idsUsados_()), fecha: ahora_(), mail: '' }, x);
    append_('Organizacion', [nuevo]);
    log_('org_alta', nuevo.id + ' · ' + x.disciplina + ' · ' + x.apellido);
    return { ok: true, org: orgInfo_(nuevo) };
  });
}
function adminOrgQuitar(token, id) {
  reset_();
  const s = ses_(token);
  return conLock_(() => {
    const r = rows_('Organizacion').find(z => z.id === id);
    if (!r || !orgPuede_(s, r.disciplina)) throw new Error('Integrante inexistente.');
    remove_('Organizacion', z => z.id === id);
    log_('org_baja', id);
    return true;
  });
}
/** Guarda la acreditación (imagen generada en el panel) en Drive y se la manda por mail. */
function adminOrgEnviar(token, id, dataUrl) {
  reset_();
  const s = ses_(token), r = rows_('Organizacion').find(z => z.id === id);
  if (!r || !orgPuede_(s, r.disciplina)) throw new Error('Integrante inexistente.');
  const m = /^data:image\/(jpeg|png);base64,(.+)$/.exec(String(dataUrl || ''));
  if (!m || m[2].length > 4e6) throw new Error('Imagen inválida.');
  guardarImagen_({ ruta: ['Organización', r.disciplina], nombre: id + ' · Acreditación organización · ' + r.apellido + ', ' + r.nombre }, id, m);
  if (MailApp.getRemainingDailyQuota() < 1) throw new Error('Se agotó la cuota diaria de mails. La acreditación quedó guardada: descargala y mandala por WhatsApp.');
  const c = cfg_();
  MailApp.sendEmail({ to: r.email, name: c.NOMBRE_REMITENTE || 'JUBU 2026', replyTo: Session.getEffectiveUser().getEmail(),
    subject: 'JUBU San Fernando 2026 · Tu acreditación de organización',
    htmlBody: marco_('Acreditación de organización', '<p>Hola ' + esc_(r.nombre) + ', te enviamos tu acreditación como parte de la organización de JUBU San Fernando 2026 (' + esc_(r.disciplina + ' · ' + r.funcion) + ').</p>' +
      '<p>Tenela en el celular (o impresa) el día del evento: identifica a la organización y se escanea para retirar la vianda.</p><p style="color:#5b7480">' + esc_(c.EVENTO_TEXTO || '') + '</p>'),
    attachments: [Utilities.newBlob(Utilities.base64Decode(m[2]), 'image/' + m[1], 'acreditacion_organizacion_' + slug_(r.apellido + ' ' + r.nombre) + (m[1] === 'png' ? '.png' : '.jpg'))] });
  conLock_(() => { const q = rows_('Organizacion').find(z => z.id === id); if (q) update_('Organizacion', q._row, { mail: 'ENVIADO ' + ahora_() }); });
  log_('org_mail', id);
  return { ok: true };
}

/* =====================================================================
   ALTA MANUAL DESDE VALIDACIÓN (PIN general) · v19
   Sumar un deportista a una lista o una disciplina entera a una delegación, aunque la inscripción esté cerrada.
   ===================================================================== */

function adminAgregarDeportista(token, listaId, p) {
  reset_();
  soloAdmin_(token);
  return conLock_(() => {
    const c = cfg_(), l = rows_('Listas').find(x => x.id === listaId);
    if (!l) throw new Error('Lista inexistente.');
    const d = disc_().find(x => x.n === l.disciplina) || { max: 99 }, parts = rows_('Participantes'), deps = parts.filter(x => x.lista === listaId);
    if (deps.length >= d.max) return { ok: false, errores: [l.disciplina + ': la lista ya tiene el máximo de ' + d.max + '. Quitá a alguien antes de sumar.'] };
    p = p || {};
    const o = { nombre: clean_(p.nombre, 60), apellido: clean_(p.apellido, 60), dni: dni_(p.dni), nac: clean_(p.nac, 10), email: clean_(p.email, 120).toLowerCase(),
      condicion: CONDICIONES.indexOf(p.cond) >= 0 ? p.cond : '', genero: GENEROS.indexOf(p.genero) >= 0 ? p.genero : '', localidad: clean_(p.localidad, 80) };
    const err = [], regla = (c.DNI_REPETIDO || 'NO_EN_MISMA_DISCIPLINA').toUpperCase();
    if (!o.nombre || !o.apellido) err.push('Falta nombre o apellido.');
    if (!okDoc_(o.dni)) err.push('DNI o pasaporte inválido.');
    if (edad_(o.nac, c.FECHA_EVENTO) < 18) err.push('Debe tener 18 años al día del evento.');
    if (!okMail_(o.email)) err.push('Email inválido.');
    if (!o.condicion || !o.genero || !o.localidad) err.push('Faltan condición, género o localidad.');
    const dup = parts.find(z => z.dni === o.dni && (regla === 'NUNCA' || z.disciplina === l.disciplina));
    if (dup) err.push('El DNI ' + o.dni + ' ya está inscripto (' + dup.disciplina + ', ' + dup.institucion + ').');
    if (err.length) return { ok: false, errores: err };
    const id = code_('JUBU26-', 6, idsUsados_());
    append_('Participantes', [Object.assign({ id: id, lista: l.id, cod: l.cod, institucion: l.institucion, disciplina: l.disciplina, rama: l.rama, presente: '', mail: '' }, o)]);
    update_('Listas', l._row, { cantidad: deps.length + 1, validada: '', enviada: '' });
    const dr = rows_('Delegaciones').find(r => r.cod === l.cod);
    if (dr && /^(ENVIADO|REENVIAR)/.test(dr.mail_jefe)) update_('Delegaciones', dr._row, { mail_jefe: 'REENVIAR · deportista agregado ' + ahora_() });
    log_('alta_manual', l.id + ' · ' + id + ' · ' + o.apellido);
    planillaDeporte_(l.disciplina);
    return { ok: true, id: id, del: delegacion_(l.cod) };
  });
}
/** lista = {disc, rama, deps:[…]} con los mismos datos que la inscripción. */
function adminAgregarDisciplina(token, cod, lista) {
  reset_();
  soloAdmin_(token);
  return conLock_(() => inscribir_({ cod: clean_(cod, 20).toUpperCase(), listas: [lista] }, true));
}

/* =====================================================================
   UTILIDADES
   ===================================================================== */

/* Caché por ejecución: cada llamada al servidor abre la planilla una sola vez y lee cada hoja una sola vez.
   Se vacía al entrar a cada función pública (reset_) y se invalida al escribir. */
let _SS = null, _SH = {}, _ROWS = {}, _NORESET = 0;
function reset_() { if (_NORESET) return; _SS = null; _SH = {}; _ROWS = {}; }
function ss_() {
  if (_SS) return _SS;
  const id = PROP.getProperty('SHEET_ID');
  if (!id) throw new Error('El sistema no está instalado (falta ejecutar setup).');
  return (_SS = SpreadsheetApp.openById(id));
}
function sheet_(n) { if (!(n in _SH)) _SH[n] = ss_().getSheetByName(n); return _SH[n]; }
function rows_(n) {
  if (!_ROWS[n]) {
    const sh = sheet_(n), h = HOJAS[n], out = [];
    if (!sh) { _ROWS[n] = []; return []; }
    const v = sh.getDataRange().getDisplayValues();
    for (let i = 1; i < v.length; i++) { const r = v[i]; let lleno = false; for (let j = 0; j < h.length; j++) if (r[j] !== '' && r[j] != null) { lleno = true; break; }
      if (lleno) { const o = { _row: i + 1 }; h.forEach((k, j) => o[k] = String(r[j] == null ? '' : r[j]).trim()); out.push(o); } }
    _ROWS[n] = out;
  }
  return _ROWS[n].map(o => Object.assign({}, o));
}
/** Escribe una columna para varias filas con una sola lectura y una sola escritura. vals = {fila: valor} */
function setCol_(n, key, vals) {
  const filas = Object.keys(vals).map(Number); if (!filas.length) return;
  const sh = sheet_(n), j = HOJAS[n].indexOf(key) + 1, a = Math.min.apply(null, filas), b = Math.max.apply(null, filas);
  const rg = sh.getRange(a, j, b - a + 1, 1), cur = rg.getDisplayValues();
  filas.forEach(f => cur[f - a][0] = vals[f] == null ? '' : String(vals[f]));
  rg.setValues(cur);
  if (_ROWS[n]) _ROWS[n].forEach(o => { if (o._row in vals) o[key] = String(vals[o._row] == null ? '' : vals[o._row]); });
}
function append_(n, objs) {
  if (!objs.length) return;
  delete _ROWS[n];
  const sh = sheet_(n), h = HOJAS[n];
  if (!sh) throw new Error('Falta la hoja ' + n + ': ejecutá setup una vez desde el editor.');
  const r = sh.getLastRow() + 1;
  sh.getRange(r, 1, objs.length, h.length).setNumberFormat('@')
    .setValues(objs.map(o => h.map(k => o[k] == null ? '' : String(o[k]))));
}
function update_(n, row, obj) {
  const sh = sheet_(n), h = HOJAS[n], rg = sh.getRange(row, 1, 1, h.length), c = _ROWS[n] && _ROWS[n].find(o => o._row === row);
  const cur = c ? h.map(k => c[k]) : rg.getDisplayValues()[0];
  h.forEach((k, j) => { if (k in obj) cur[j] = obj[k] == null ? '' : String(obj[k]); });
  rg.setValues([cur]);
  if (c) h.forEach((k, j) => c[k] = cur[j]);
}
function remove_(n, pred) {
  const sh = sheet_(n), all = rows_(n), keep = all.filter(o => !pred(o)), h = HOJAS[n];
  if (keep.length === all.length) return 0;
  delete _ROWS[n];
  const last = sh.getLastRow(), filas = Math.max(last - 1, keep.length);
  if (filas > 0) {
    const vals = keep.map(o => h.map(k => o[k] == null ? '' : o[k]));
    while (vals.length < filas) vals.push(h.map(() => ''));
    sh.getRange(2, 1, filas, h.length).setValues(vals);   // un solo paso: datos que quedan + vacíos al final
  }
  return all.length - keep.length;
}
function cfg_() { const c = {}; rows_('General').forEach(r => c[r.clave] = r.valor); return c; }
function disc_() {
  return rows_('Disciplinas').map(r => ({
    n: r.disciplina, min: Number(r.min) || 1, max: Number(r.max) || 1,
    ramas: r.ramas ? r.ramas.split(',').map(s => s.trim()).filter(String) : [],
    tipo: r.tipo === 'equipo' ? 'equipo' : 'individual', pin: r.pin_mesa,
    formato: r.formato === 'puntaje' || r.formato === 'partidos' ? r.formato : formatoDef_(r.disciplina, r.tipo)
  }));
}
/** Cómo se define cada disciplina: 'partidos' (llave, grupos, enfrentamientos) o 'puntaje' (ranking por puntaje/tiempo). */
const FORMATO_PARTIDOS = ['Ajedrez', 'Freestyle Rap', 'Breaking'];
function formatoDef_(n, tipo) { return tipo === 'equipo' || FORMATO_PARTIDOS.indexOf(n) >= 0 ? 'partidos' : 'puntaje'; }
function ahora_() { return Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm:ss'); }
function pin_(n) { let s = ''; for (let i = 0; i < n; i++) s += Math.floor(Math.random() * 10); return s; }
const ALFA = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const ABREV = { 'BMX Freestyle': 'BMX', 'Skate': 'SKT', 'Roller Freestyle': 'ROL', 'Quad Skate': 'QUAD', 'Parkour': 'PKR', 'Breaking': 'BRK', 'Freestyle Rap': 'RAP',
  'Básquet 3x3': 'B3X3', 'Beisbol 5': 'BB5', 'Cestoball 3x3': 'C3X3', 'Ajedrez': 'AJD', 'Fútbol Freestyle': 'FTF' };
function sinTildes_(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, ''); }
/** Sigla de la institución: la que indicó el jefe/a, o las iniciales (Universidad Nacional del Delta → UND). */
function sigla_(inst, dada) {
  let s = sinTildes_(dada).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 10);
  if (s.length >= 2) return s;
  const pal = sinTildes_(inst).toUpperCase().replace(/[^A-Z0-9 ]/g, ' ').split(/\s+/).filter(Boolean);
  if (pal.length === 1) return pal[0].slice(0, 10);
  s = pal.filter(w => ['DE', 'DEL', 'LA', 'LAS', 'LOS', 'EL', 'Y', 'E'].indexOf(w) < 0).map(w => w[0]).join('');
  return (s || 'INST').slice(0, 8);
}
function abrev_(disc) { return ABREV[disc] || sinTildes_(disc).toUpperCase().replace(/[^A-Z0-9]/g, '').slice(0, 4); }
/** Código único a partir de una base legible: UND, UND2, UND3… / UND-B3X3-F, UND-B3X3-F-2… */
function codigo_(base, usados, sep) {
  if (!usados.has(base)) { usados.add(base); return base; }
  for (let i = 2; ; i++) { const c = base + (sep || '') + i; if (!usados.has(c)) { usados.add(c); return c; } }
}
function code_(pref, n, usados) {
  for (;;) { let s = pref; for (let i = 0; i < n; i++) s += ALFA[Math.floor(Math.random() * ALFA.length)]; if (!usados.has(s)) { usados.add(s); return s; } }
}
function clean_(s, max) { return String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').trim().replace(/^[=+\-@]+/, '').slice(0, max || 120); }
function esc_(s) { return String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c])); }
/** DNI o pasaporte: mayúsculas, sin puntos, guiones ni espacios. */
function dni_(s) { return String(s == null ? '' : s).toUpperCase().replace(/[^0-9A-Z]/g, ''); }
/** DNI (7 u 8 números) o pasaporte (6 a 12 letras/números). */
function okDoc_(v) { return /^[0-9A-Z]{6,12}$/.test(v); }
function okMail_(s) { return /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(s); }
function edad_(nac, evento) {
  const m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(nac), e = /^(\d{4})-(\d{2})-(\d{2})$/.exec(evento || '2026-10-17');
  if (!m || !e) return -1;
  let a = +e[1] - +m[1];
  if (+e[2] < +m[2] || (+e[2] === +m[2] && +e[3] < +m[3])) a--;
  return a;
}
function abierta_(c) {
  if ((c.INSCRIPCION_ABIERTA || 'SI').toUpperCase() !== 'SI') return false;
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:\s+(\d{1,2}):(\d{2}))?/.exec(c.CIERRE || '');
  if (!m) return true;
  const cierre = new Date(m[1] + '-' + m[2] + '-' + m[3] + 'T' + ('0' + (m[4] || '23')).slice(-2) + ':' + (m[5] || '59') + ':59-03:00');
  return new Date() <= cierre;
}
const _LOGS = []; let _LOCKD = 0;
function log_(accion, detalle) { _LOGS.push({ fecha: ahora_(), accion: accion, detalle: String(detalle).slice(0, 500) }); if (!_LOCKD) flushLog_(); }
function flushLog_() { if (!_LOGS.length) return; const x = _LOGS.splice(0, _LOGS.length); try { append_('Log', x); } catch (e) {} }
function conLock_(fn) {
  const l = LockService.getScriptLock();
  if (!l.tryLock(30000)) throw new Error('El sistema está ocupado. Probá de nuevo en unos segundos.');
  _LOCKD++;
  try { return fn(); } finally { _LOCKD--; if (!_LOCKD) { flushLog_(); if (_LIMPIAR) limpiarAhora_(); } l.releaseLock(); }
}
function limite_(clave, max, seg) {
  const c = CacheService.getScriptCache(), k = 'lim_' + clave, n = Number(c.get(k) || 0);
  if (n >= max) throw new Error('Demasiados intentos. Esperá unos minutos y volvé a probar.');
  c.put(k, String(n + 1), seg);
}
/** Guarda la respuesta pública en caché (60 s). Comprimida si hace falta; si igual no entra (límite de Google: 100 KB), sigue sin caché. */
function guardarPublico_(cache, out) {
  const s = JSON.stringify(out);
  try {
    if (s.length < 90000) { cache.put('publico', s, 60); return; }
    const z = 'z:' + Utilities.base64Encode(Utilities.gzip(Utilities.newBlob(s, 'application/json')).getBytes());
    if (z.length < 95000) cache.put('publico', z, 60);
  } catch (e) {}
}
/** La caché pública se borra DESPUÉS de guardar en la planilla (si alguien consulta en el medio, no queda el dato viejo). */
let _LIMPIAR = false;
function limpiarCachePublico_() { if (_LOCKD) { _LIMPIAR = true; return; } limpiarAhora_(); }
function limpiarAhora_() { _LIMPIAR = false; try { SpreadsheetApp.flush(); } catch (e) {} try { CacheService.getScriptCache().remove('publico'); } catch (e) {} }

/* =====================================================================
   API PORTAL PÚBLICO
   ===================================================================== */

function normInst_(s) { return String(s || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]/g, ''); }
function instituciones_() { return sheet_('Instituciones') ? rows_('Instituciones').filter(r => r.nombre) : INST_INICIAL.map(x => ({ nombre: x[0], sigla: x[1] })); }
/** Nombre oficial de una institución escrita a mano ("UNDelta", "unsam", "Universidad Nacional del Delta" → nombre de la lista). */
function instCanon_(s) {
  const n = normInst_(s), x = n && instituciones_().find(r => normInst_(r.nombre) === n || normInst_(r.sigla) === n);
  return x ? { nombre: x.nombre, sigla: x.sigla, lista: true } : { nombre: clean_(s), sigla: '', lista: false };
}
function apiConfig() {
  reset_();
  const cache = CacheService.getScriptCache(), hit = cache.get('cfg');
  if (hit) return JSON.parse(hit);
  const out = apiConfigCalc_();
  try { cache.put('cfg', JSON.stringify(out), 120); } catch (e) {}
  return out;
}
function apiConfigCalc_() {
  const c = cfg_();
  return {
    insts: instituciones_().map(r => [r.nombre, r.sigla]),
    disc: disc_().map(d => ({ n: d.n, min: d.min, max: d.max, ramas: d.ramas.length ? d.ramas : null, tipo: d.tipo })),
    abierta: abierta_(c), cierre: c.CIERRE || '', condiciones: CONDICIONES, url: urlPortal_(), evento: c.EVENTO_TEXTO || ''
  };
}

function delegacion_(cod) {
  const d = rows_('Delegaciones').find(r => r.cod === cod);
  if (!d) return null;
  const parts = rows_('Participantes').filter(p => p.cod === cod);
  return {
    cod: d.cod, inst: d.institucion, mail: d.mail_jefe,
    jefe: { nombre: d.jefe_nombre, apellido: d.jefe_apellido, dni: d.jefe_dni, nac: d.jefe_nac, cargo: d.cargo, tel: d.celular, email: d.email, id: d.jefe_id },
    listas: rows_('Listas').filter(l => l.cod === cod).map(l => ({
      id: l.id, disc: l.disciplina, rama: l.rama, presente: l.presente, validada: /^SI/.test(l.validada), enviada: !!l.enviada,
      deps: parts.filter(p => p.lista === l.id).map(p => ({ id: p.id, nombre: p.nombre, apellido: p.apellido, dni: p.dni, nac: p.nac, email: p.email, cond: p.condicion, genero: p.genero, localidad: p.localidad }))
    }))
  };
}

function auth_(cod, dni) {
  cod = clean_(cod, 20).toUpperCase(); dni = dni_(dni);
  const d = rows_('Delegaciones').find(r => r.cod === cod && r.jefe_dni === dni);
  if (!d) throw new Error('Delegación no encontrada para ese DNI y código.');
  return cod;
}

/** El jefe/a pide una corrección de datos (la organización la ve en el panel y le llega por mail). */
function apiPedirCorreccion(cod, dni, texto) {
  reset_();
  reset_();
  cod = auth_(cod, dni); texto = clean_(texto, 1000);
  if (texto.length < 5) return { ok: false, error: 'Contanos qué hay que corregir.' };
  limite_('corr_' + cod, 6, 3600);
  const d = rows_('Delegaciones').find(r => r.cod === cod), c = cfg_();
  conLock_(() => append_('Correcciones', [{ fecha: ahora_(), cod: cod, institucion: d.institucion, jefe: d.jefe_nombre + ' ' + d.jefe_apellido, email: d.email, texto: texto, estado: 'PENDIENTE' }]));
  try { MailApp.sendEmail({ to: c.MAIL_ORGANIZACION || Session.getEffectiveUser().getEmail(), replyTo: d.email, name: c.NOMBRE_REMITENTE || 'JUBU 2026',
    subject: 'JUBU 2026 · Pedido de corrección · ' + d.institucion + ' (' + cod + ')', body: 'Jefe/a: ' + d.jefe_nombre + ' ' + d.jefe_apellido + ' · ' + d.email + ' · ' + d.celular + '\n\n' + texto + '\n\nSe corrige en el panel de organización → Validación.' }); } catch (e) {}
  return { ok: true };
}
function adminCorreccion(token, fila, estado) {
  reset_();
  reset_(); soloAdmin_(token);
  return conLock_(() => { const r = rows_('Correcciones').find(x => x._row === Number(fila)); if (!r) throw new Error('Pedido inexistente.'); update_('Correcciones', r._row, { estado: estado === 'PENDIENTE' ? 'PENDIENTE' : 'RESUELTO ' + ahora_() }); return true; });
}
function apiLogin(email, dni) {
  reset_();
  email = clean_(email, 120).toLowerCase(); dni = dni_(dni);
  limite_('login_' + email, 10, 3600);
  const d = rows_('Delegaciones').find(r => r.email.toLowerCase() === email && r.jefe_dni === dni);
  if (!d) return { ok: false, error: 'No encontramos una delegación con ese email y DNI del jefe/a.' };
  return { ok: true, del: delegacion_(d.cod), abierta: abierta_(cfg_()) };
}

/**
 * req = { jefe?:{inst,nombre,apellido,dni,nac,cargo,tel,email}, cod?, dni?,
 *         listas:[{disc,rama,deps:[{nombre,apellido,dni,nac,email,cond}]}] }
 */
function apiInscribir(req) {
  reset_();
  const r = conLock_(() => inscribir_(req, false));
  if (r && r._mail) {
    try { MailApp.sendEmail(r._mail); } catch (e) { log_('mail_confirmacion_error', r.del.cod + ' · ' + e.message); }
    delete r._mail;
  }
  return r;
}
function inscribir_(req, admin) {
  {
    const c = cfg_(), DISC = disc_(), err = [];
    if (!abierta_(c) && !admin) return { ok: false, errores: ['La inscripción está cerrada.'] };
    req = req || {};
    const dels = rows_('Delegaciones');
    let cod = null, inst = '', nuevaDel = null, delPrev = null;

    if (req.cod) {
      cod = clean_(req.cod, 20).toUpperCase();
      const d = dels.find(r => r.cod === cod && (admin || r.jefe_dni === dni_(req.dni)));
      if (!d) return { ok: false, errores: ['Delegación no encontrada para ese DNI y código.'] };
      inst = d.institucion; delPrev = d;
    } else if (admin) return { ok: false, errores: ['Falta la delegación.'] };
    else {
      const j = req.jefe || {};
      const jefe = { sigla: clean_(j.sigla, 12), inst: clean_(j.inst), nombre: clean_(j.nombre, 60), apellido: clean_(j.apellido, 60), dni: dni_(j.dni), nac: clean_(j.nac, 10),
        cargo: clean_(j.cargo, 80), tel: clean_(j.tel, 30), email: clean_(j.email, 120).toLowerCase() };
      ['inst', 'nombre', 'apellido', 'cargo', 'tel'].forEach(k => { if (!jefe[k]) err.push('Jefe/a: falta ' + ({ inst: 'institución', tel: 'celular' }[k] || k) + '.'); });
      if (!okDoc_(jefe.dni)) err.push('Jefe/a: DNI o pasaporte inválido.');
      if (edad_(jefe.nac, c.FECHA_EVENTO) < 18) err.push('Jefe/a: debe tener 18 años al día del evento.');
      if (!okMail_(jefe.email)) err.push('Jefe/a: email inválido.');
      const ic = instCanon_(jefe.inst); jefe.inst = ic.nombre; if (!jefe.sigla && ic.sigla) jefe.sigla = ic.sigla;
      const mia = dels.find(r => r.jefe_dni === jefe.dni);
      if (mia) {
        // mismo envío repetido (se cortó la conexión y se volvió a enviar): devolver la delegación ya creada
        const ps = rows_('Participantes').filter(p => p.cod === mia.cod), pedidas = (Array.isArray(req.listas) ? req.listas : []).flatMap(l => (l.deps || []).map(p => dni_(p.dni)));
        if (mia.email.toLowerCase() === jefe.email && pedidas.length && pedidas.every(x => ps.some(p => p.dni === x))) return { ok: true, del: delegacion_(mia.cod), nuevos: [], repetido: true };
        err.push('Ya existe una delegación con el documento ' + jefe.dni + '. Ingresá por "Ya inscribí mi delegación" con tu email y documento.');
      } else {
        const otra = dels.find(r => normInst_(instCanon_(r.institucion).nombre) === normInst_(jefe.inst));
        if (otra) err.push(jefe.inst + ' ya tiene delegación (jefe/a: ' + otra.jefe_nombre + ' ' + otra.jefe_apellido + '). Hay un solo jefe/a por institución: pedile que sume las disciplinas, o escribí a la organización.');
      }
      nuevaDel = jefe; inst = jefe.inst;
    }

    const listas = Array.isArray(req.listas) ? req.listas.slice(0, 30) : [];
    if (!listas.length) err.push('Agregá al menos una lista de buena fe.');

    const existentes = rows_('Participantes'), regla = (c.DNI_REPETIDO || 'NO_EN_MISMA_DISCIPLINA').toUpperCase();
    const clave = (disc, dni) => regla === 'NUNCA' ? dni : disc + '|' + dni;
    const ocupado = new Map();
    existentes.forEach(p => ocupado.set(clave(p.disciplina, p.dni), p));
    const limpias = [];

    listas.forEach(l => {
      const d = DISC.find(x => x.n === l.disc);
      if (!d) { err.push('Disciplina inexistente: ' + clean_(l.disc, 40) + '.'); return; }
      let rama = clean_(l.rama, 30);
      if (d.ramas.length) { if (d.ramas.indexOf(rama) < 0) { err.push(d.n + ': elegí una rama válida.'); return; } } else rama = '';
      const deps = Array.isArray(l.deps) ? l.deps : [];
      if (deps.length < d.min || deps.length > d.max) err.push(d.n + ': tiene que tener entre ' + d.min + ' y ' + d.max + ' participantes (cargaste ' + deps.length + ').');
      const vistos = new Set(), ok = [];
      deps.slice(0, d.max).forEach((p, i) => {
        const o = { nombre: clean_(p.nombre, 60), apellido: clean_(p.apellido, 60), dni: dni_(p.dni), nac: clean_(p.nac, 10),
          email: clean_(p.email, 120).toLowerCase(), cond: CONDICIONES.indexOf(p.cond) >= 0 ? p.cond : '',
          genero: GENEROS.indexOf(p.genero) >= 0 ? p.genero : '', localidad: clean_(p.localidad, 80) };
        const q = d.n + ' · participante ' + (i + 1) + ': ';
        if (!o.nombre || !o.apellido) err.push(q + 'falta nombre o apellido.');
        if (!okDoc_(o.dni)) err.push(q + 'DNI o pasaporte inválido.');
        if (edad_(o.nac, c.FECHA_EVENTO) < 18) err.push(q + 'debe tener 18 años al día del evento.');
        if (!okMail_(o.email)) err.push(q + 'email inválido.');
        if (!o.cond) err.push(q + 'falta la condición.');
        if (!o.genero) err.push(q + 'falta el género.');
        if (!o.localidad) err.push(q + 'falta la localidad de residencia.');
        if (vistos.has(o.dni)) err.push(q + 'DNI ' + o.dni + ' repetido en la lista.');
        vistos.add(o.dni);
        const k = clave(d.n, o.dni), prev = ocupado.get(k);
        if (prev) err.push(q + 'el DNI ' + o.dni + ' ya está inscripto' + (regla === 'NUNCA' ? ' en ' + prev.disciplina : ' en esta disciplina') + (prev.institucion ? ' (' + prev.institucion + ')' : '') + '.');
        else ocupado.set(k, { disciplina: d.n, institucion: inst });
        ok.push(o);
      });
      limpias.push({ disc: d.n, rama: rama, deps: ok });
    });

    if (err.length) return { ok: false, errores: Array.from(new Set(err)).slice(0, 12) };

    const usados = new Set();
    dels.forEach(r => { usados.add(r.cod); usados.add(r.jefe_id); });
    rows_('Listas').forEach(r => usados.add(r.id));
    existentes.forEach(r => usados.add(r.id));
    const f = ahora_(), nuevos = [];

    if (nuevaDel) {
      cod = codigo_(sigla_(nuevaDel.inst, nuevaDel.sigla), usados, '');
      const jid = code_('JUBU26-', 6, usados);
      append_('Delegaciones', [{ cod: cod, fecha: f, institucion: nuevaDel.inst, jefe_nombre: nuevaDel.nombre, jefe_apellido: nuevaDel.apellido,
        jefe_dni: nuevaDel.dni, jefe_nac: nuevaDel.nac, cargo: nuevaDel.cargo, celular: nuevaDel.tel, email: nuevaDel.email, jefe_id: jid, mail_jefe: '', sigla: cod }]);
      nuevos.push(jid);
    }
    const L = [], P = [];
    limpias.forEach(l => {
      const lid = codigo_(cod + '-' + abrev_(l.disc) + (l.rama ? '-' + sinTildes_(l.rama)[0].toUpperCase() : ''), usados, '-');
      nuevos.push(lid);
      L.push({ id: lid, cod: cod, fecha: f, institucion: inst, disciplina: l.disc, rama: l.rama, cantidad: l.deps.length, presente: '', hora_presente: '', mesa: '', validada: '' });
      l.deps.forEach(p => {
        const pid = code_('JUBU26-', 6, usados);
        nuevos.push(pid);
        P.push({ id: pid, lista: lid, cod: cod, institucion: inst, disciplina: l.disc, rama: l.rama, nombre: p.nombre, apellido: p.apellido,
          dni: p.dni, nac: p.nac, email: p.email, condicion: p.cond, presente: '', mail: '', genero: p.genero, localidad: p.localidad });
      });
    });
    append_('Listas', L);
    append_('Participantes', P);
    if (delPrev && /^(ENVIADO|REENVIAR)/.test(delPrev.mail_jefe)) update_('Delegaciones', delPrev._row, { mail_jefe: 'REENVIAR · nueva disciplina ' + f });
    log_('inscripcion', cod + ' · ' + L.length + ' listas · ' + P.length + ' deportistas');
    Array.from(new Set(L.map(l => l.disciplina))).forEach(planillaDeporte_);
    const del = delegacion_(cod);
    const out = { ok: true, del: del, nuevos: nuevos };
    if (!admin && (c.MAIL_CONFIRMACION || 'SI').toUpperCase() === 'SI') out._mail = { to: del.jefe.email, name: c.NOMBRE_REMITENTE || 'JUBU 2026', replyTo: Session.getEffectiveUser().getEmail(),
      subject: 'JUBU San Fernando 2026 · Inscripción recibida · ' + cod, htmlBody: mailConfirmacion_(del, L.map(l => l.id), c) };
    return out;
  }
}

/* ---------- Drive: Deportes / <Deporte> / <Universidad> / listas y acreditaciones ---------- */

function nombreCarpeta_(s) { return String(s || 'Sin dato').replace(/[\\/:*?"<>|]/g, '-').trim().slice(0, 100) || 'Sin dato'; }
/** Devuelve (y crea si falta) la carpeta de la ruta pedida dentro de "JUBU 2026 · Sistema". */
function carpeta_(ruta, crear) {
  let f = DriveApp.getFolderById(PROP.getProperty('FOLDER_ID')), key = 'F';
  for (const parte of ruta) {
    const n = nombreCarpeta_(parte);
    key += '|' + n.toLowerCase();
    const id = PROP.getProperty(key);
    if (id) { try { f = DriveApp.getFolderById(id); continue; } catch (e) {} }
    const it = f.getFoldersByName(n);
    if (it.hasNext()) f = it.next();
    else if (!crear) return null;
    else f = f.createFolder(n);
    PROP.setProperty(key, f.getId());
  }
  return f;
}
function urlDeportes_() { let u = PROP.getProperty('URL|Deportes'); if (!u) { u = carpeta_(['Deportes'], true).getUrl(); PROP.setProperty('URL|Deportes', u); } return u; }
/** Ubicación y nombre de archivo de cada imagen según su ID. */
function destino_(del, id) {
  if (id === del.jefe.id) return { ruta: ['Jefes de delegación'], nombre: id + ' · Acreditación jefe-a · ' + del.jefe.apellido + ', ' + del.jefe.nombre + ' · ' + del.inst };
  for (const l of del.listas) {
    const disc = l.disc + (l.rama ? ' ' + l.rama : '');
    if (l.id === id) return { ruta: ['Deportes', l.disc, del.inst], nombre: id + ' · Lista de buena fe · ' + disc };
    const p = l.deps.find(x => x.id === id);
    if (p) return { ruta: ['Deportes', l.disc, del.inst], nombre: id + ' · Acreditación · ' + p.apellido + ', ' + p.nombre + ' · ' + disc };
  }
  return null;
}

/** Guarda una imagen generada en el portal (lista o acreditación) en la carpeta del deporte y la universidad. */
function subirImagenJefe_(cod, dni, id, dataUrl) {
  cod = auth_(cod, dni);
  const del = delegacion_(cod), d = destino_(del, id);
  if (!d) throw new Error('Imagen no corresponde a la delegación.');
  const m = /^data:image\/(jpeg|png);base64,(.+)$/.exec(String(dataUrl || ''));
  if (!m || m[2].length > 4e6) throw new Error('Imagen inválida.');
  return guardarImagen_(d, id, m);
}
function guardarImagen_(d, id, m) {
  const ext = m[1] === 'png' ? 'png' : 'jpg';
  const folder = conLock_(() => carpeta_(d.ruta, true));
  archivos_(folder, id).forEach(f => f.setTrashed(true));
  folder.createFile(Utilities.newBlob(Utilities.base64Decode(m[2]), 'image/' + m[1], nombreCarpeta_(d.nombre) + '.' + ext));
  return true;
}
/** Archivos cuyo nombre empieza exactamente con "<id> · " (evita confundir UND-BMX con UND-BMX-2). */
function archivos_(folder, id) {
  const out = [], it = folder.searchFiles('title contains "' + id.replace(/"/g, '') + '" and trashed = false');
  while (it.hasNext()) { const f = it.next(); if (String(f.getName ? f.getName() : f.blob.name).indexOf(id + ' · ') === 0) out.push(f); }
  return out;
}

function imagen_(del, id, nombreArchivo) {
  const d = destino_(del, id), f = d && carpeta_(d.ruta, false);
  if (f) {
    const fs = archivos_(f, id);
    if (fs.length) { const b = fs[0].getBlob(); return b.setName(nombreArchivo + (/png/.test(b.getContentType ? b.getContentType() : '') ? '.png' : '.jpg')); }
  }
  const old = PROP.getProperty('IMG_FOLDER_ID') && DriveApp.getFolderById(PROP.getProperty('IMG_FOLDER_ID'));
  if (old) for (const ext of ['jpg', 'png']) { const it = old.getFilesByName(id + '.' + ext); if (it.hasNext()) return it.next().getBlob().setName(nombreArchivo + '.' + ext); }
  return null;
}

/* ---------- planilla de inscriptos por deporte (dentro de la carpeta de cada deporte) ---------- */

const COLS_DEP = ['Institución', 'Rama', 'Lista', 'Presente lista', 'Apellido', 'Nombre', 'DNI', 'Fecha de nac.', 'Género', 'Localidad', 'Email', 'Condición', 'Presente', 'Acreditación', 'Jefe/a de delegación', 'Email jefe/a', 'Celular jefe/a', 'Delegación'];
/** Marca la planilla del deporte para actualizar (la actualiza el activador de cada minuto). */
function planillaDeporte_(disc) {
  try { const s = new Set((PROP.getProperty('PL_SUCIAS') || '').split('|').filter(String)); if (!s.has(disc)) { s.add(disc); PROP.setProperty('PL_SUCIAS', Array.from(s).join('|')); } } catch (e) {}
}
/** Activador (cada 1 minuto): regenera solo las planillas por deporte que cambiaron. */
function actualizarPlanillas() {
  reset_();
  const l = LockService.getScriptLock(); if (!l.tryLock(20000)) return 'ocupado';
  let s = '';
  try { s = PROP.getProperty('PL_SUCIAS') || ''; if (s) PROP.deleteProperty('PL_SUCIAS'); } finally { l.releaseLock(); }
  const ds = s.split('|').filter(String); ds.forEach(planillaDeporteAhora_); return ds.length;
}
function programarPlanillas_() {
  ScriptApp.getProjectTriggers().forEach(t => { if (t.getHandlerFunction() === 'actualizarPlanillas') ScriptApp.deleteTrigger(t); });
  ScriptApp.newTrigger('actualizarPlanillas').timeBased().everyMinutes(1).create();
  return 'cada 1 minuto';
}
function planillaDeporteAhora_(disc) {
  try {
    const key = 'PL|' + disc;
    let ss = null, id = PROP.getProperty(key);
    if (id) { try { ss = SpreadsheetApp.openById(id); } catch (e) { ss = null; } }
    if (!ss) {
      ss = SpreadsheetApp.create('Inscriptos · ' + disc + ' · JUBU 2026');
      DriveApp.getFileById(ss.getId()).moveTo(carpeta_(['Deportes', disc], true));
      PROP.setProperty(key, ss.getId());
    }
    const dels = rows_('Delegaciones'), listas = rows_('Listas').filter(l => l.disciplina === disc);
    const filas = rows_('Participantes').filter(p => p.disciplina === disc).map(p => {
      const d = dels.find(x => x.cod === p.cod) || {}, l = listas.find(x => x.id === p.lista) || {};
      return [p.institucion, p.rama, p.lista, l.presente || '', p.apellido, p.nombre, p.dni, p.nac, p.genero, p.localidad, p.email, p.condicion, p.presente, p.id,
        (d.jefe_nombre || '') + ' ' + (d.jefe_apellido || ''), d.email || '', d.celular || '', p.cod];
    }).sort((a, b) => (a[0] + a[1] + a[2] + a[4]).localeCompare(b[0] + b[1] + b[2] + b[4]));
    const sh = ss.getSheets()[0];
    sh.setName('Inscriptos');
    sh.clearContents();
    sh.getRange(1, 1, 1, COLS_DEP.length).setValues([COLS_DEP]).setFontWeight('bold').setBackground('#24546b').setFontColor('#ffffff');
    sh.setFrozenRows(1);
    if (filas.length) sh.getRange(2, 1, filas.length, COLS_DEP.length).setNumberFormat('@').setValues(filas);
    return ss.getUrl();
  } catch (e) { log_('planilla_deporte_error', disc + ' · ' + e.message); return ''; }
}
/** Regenera todas las planillas por deporte (ejecutar desde el editor si se corrigieron datos a mano). */
function regenerarPlanillasDeporte() { reset_(); disc_().forEach(d => planillaDeporteAhora_(d.n)); return 'OK'; }

function slug_(s) { return String(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''); }

/** Envía al jefe/a de delegación el mail con las listas y acreditaciones nuevas adjuntas (solo al jefe/a). */
function enviarMailsJefe_(cod, dni, ids) {
  cod = auth_(cod, dni);
  return enviarJefe_(cod, new Set(ids || []));
}

/** nuevos = Set de IDs a adjuntar; null = adjuntar todo (reenvío completo). */
/** Qué falta enviar: listas validadas sin enviar (y sus acreditaciones). Si ninguna lista fue enviada todavía, va todo con el jefe/a. */
function pendientesEnvio_(cod) {
  const d = rows_('Delegaciones').find(r => r.cod === cod), Ls = rows_('Listas').filter(l => l.cod === cod);
  const prev = d && /^ENVIADO (\S+ \S+)/.exec(d.mail_jefe), enviada = l => !!l.enviada || (prev && /^SI /.test(l.validada) && l.validada.slice(3) <= prev[1]);
  const nuevas = Ls.filter(l => /^SI/.test(l.validada) && !enviada(l));
  return { nuevas: nuevas.map(l => l.id), primera: !Ls.some(enviada), todas: Ls.map(l => l.id) };
}
function enviarJefe_(cod, nuevos) {
  const pe = pendientesEnvio_(cod);
  if (!nuevos) nuevos = pe.primera || !pe.nuevas.length ? null : new Set(pe.nuevas);
  const parcial = !!nuevos, listasIds = nuevos ? pe.nuevas : pe.todas;
  if (nuevos) rows_('Participantes').filter(p => nuevos.has(p.lista)).forEach(p => nuevos.add(p.id));
  const c = cfg_(), del = delegacion_(cod), j = del.jefe, todo = !nuevos, adj = [];
  const incl = id => todo || nuevos.has(id);
  let faltan = 0;
  const add = (id, nombre) => { if (!incl(id)) return; const b = imagen_(del, id, nombre); b ? adj.push(b) : faltan++; };
  add(j.id, 'acreditacion_jefe_' + slug_(j.apellido));
  del.listas.forEach(l => {
    add(l.id, 'lista_' + slug_(l.disc + ' ' + l.rama) + '_' + l.id);
    l.deps.forEach(p => add(p.id, 'acreditacion_' + slug_(p.apellido + ' ' + p.nombre)));
  });
  const partes = [];
  let cur = [], tam = 0;
  adj.forEach(b => { const s = b.getBytes().length; if (cur.length && tam + s > 18e6) { partes.push(cur); cur = []; tam = 0; } cur.push(b); tam += s; });
  partes.push(cur);
  if (MailApp.getRemainingDailyQuota() < partes.length) {
    marcarJefe_(cod, 'PENDIENTE');
    throw new Error('Se agotó la cuota diaria de mails. Las listas quedaron guardadas y la organización reenvía el mail.');
  }
  const nuevasListas = del.listas.filter(l => incl(l.id));
  partes.forEach((p, i) => MailApp.sendEmail({
    to: j.email, name: c.NOMBRE_REMITENTE || 'JUBU 2026', replyTo: Session.getEffectiveUser().getEmail(),
    subject: 'JUBU San Fernando 2026 · Delegación ' + cod + (partes.length > 1 ? ' (parte ' + (i + 1) + ' de ' + partes.length + ')' : ''),
    htmlBody: mailJefe_(del, nuevasListas, p.length, c, parcial), attachments: p
  }));
  const fe = ahora_(); marcarJefe_(cod, 'ENVIADO ' + fe);
  rows_('Listas').filter(l => listasIds.indexOf(l.id) >= 0 && /^SI/.test(l.validada)).forEach(l => update_('Listas', l._row, { enviada: fe }));
  log_('mail_jefe', cod + ' · ' + adj.length + ' adjuntos' + (faltan ? ' · faltan ' + faltan : ''));
  return { jefe: true, adjuntos: adj.length, faltan: faltan, parcial: parcial };
}
function marcarJefe_(cod, estado) {
  const dr = rows_('Delegaciones').find(r => r.cod === cod);
  if (dr) update_('Delegaciones', dr._row, { mail_jefe: estado });
}

/** Reenvía a los jefes/as con mail PENDIENTE (ejecutar desde el editor, por ejemplo al día siguiente). */
function reenviarPendientes() {
  reset_();
  let n = 0;
  rows_('Delegaciones').filter(d => /^PENDIENTE/.test(d.mail_jefe)).forEach(d => { if (MailApp.getRemainingDailyQuota() > 0) { enviarJefe_(d.cod, null); n++; } });
  Logger.log('Reenviados: ' + n);
  return n;
}

function marco_(titulo, cuerpo) {
  return '<div style="background:#9fd3c2;padding:24px 12px;font-family:Montserrat,Arial,sans-serif;color:#16364a">' +
    '<div style="max-width:560px;margin:0 auto;background:#ffffff;border-radius:22px;overflow:hidden">' +
    '<div style="background:#24546b;color:#ffffff;padding:22px 26px"><div style="font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:#9fd3c2">JUBU San Fernando 2026</div>' +
    '<div style="font-size:22px;font-weight:800;margin-top:6px">' + titulo + '</div></div>' +
    '<div style="padding:22px 26px;font-size:14px;line-height:1.6">' + cuerpo + '</div></div>' +
    '<p style="text-align:center;font-size:11px;color:#1b3f52;margin-top:14px">UNDelta · FeDUA · Municipio de San Fernando · Provincia de Buenos Aires</p></div>';
}
function mailConfirmacion_(del, nuevas, c) {
  const filas = del.listas.map(l => '<tr><td style="padding:6px 8px;border-bottom:1px solid #d5e4e6">' + esc_(l.disc + (l.rama ? ' · ' + l.rama : '')) + (nuevas.indexOf(l.id) >= 0 ? ' <b style="color:#e8913a">nueva</b>' : '') +
    '</td><td style="padding:6px 8px;border-bottom:1px solid #d5e4e6;text-align:center">' + l.deps.length + '</td></tr>').join('');
  return marco_('Inscripción recibida',
    '<p>Hola ' + esc_(del.jefe.nombre) + ', recibimos la inscripción de <b>' + esc_(del.inst) + '</b> (delegación <b>' + esc_(del.cod) + '</b>).</p>' +
    '<table style="border-collapse:collapse;width:100%;font-size:13px"><tr style="background:#f3f8f8"><th style="text-align:left;padding:6px 8px">Disciplina</th><th style="padding:6px 8px">Deportistas</th></tr>' + filas + '</table>' +
    '<p><b>Próximo paso:</b> la organización revisa y valida los datos, y te envía por mail las acreditaciones y las listas de buena fe con QR a medida que las valida. Podés seguir sumando disciplinas y equipos hasta el cierre de la inscripción (' + esc_((c.CIERRE || '').slice(0, 10).split('-').reverse().join('/')) + ').</p>' +
    '<p>Hasta el cierre podés sumar disciplinas desde el portal: "Ya inscribí mi delegación", con este email y tu DNI como contraseña.</p>' +
    '<p style="color:#5b7480">' + esc_(c.EVENTO_TEXTO || '') + '</p>');
}
function mailJefe_(del, nuevas, nAdj, c, parcial) {
  const url = urlPortal_();
  const filas = del.listas.map(l => '<tr><td style="padding:6px 8px;border-bottom:1px solid #d5e4e6">' + esc_(l.disc + (l.rama ? ' · ' + l.rama : '')) +
    '</td><td style="padding:6px 8px;border-bottom:1px solid #d5e4e6">' + esc_(l.id) + '</td><td style="padding:6px 8px;border-bottom:1px solid #d5e4e6;text-align:center">' + l.deps.length + '</td></tr>').join('');
  return marco_('Delegación ' + esc_(del.inst),
    '<p>Hola ' + esc_(del.jefe.nombre) + ', la organización validó los datos que completaste en la inscripción. Te enviamos las acreditaciones que fueron validadas hasta el momento. Ante cualquier inconveniente, comunicate con el comité organizador.</p>' +
    (parcial ? '<p>En este envío: <b>' + esc_(nuevas.map(l => l.disc + (l.rama ? ' ' + l.rama : '')).join(', ')) + '</b>. Las acreditaciones anteriores ya las tenés.</p>' : '') +
    '<p style="background:#eef8f1;border-radius:12px;padding:10px 14px"><b>Podés seguir cargando:</b> hasta el cierre de la inscripción podés sumar disciplinas y equipos desde el portal, en "Ya inscribí mi delegación". Lo nuevo se valida y te llega en otro mail.</p>' +
    '<div style="background:#24546b;color:#fff;border-radius:16px;padding:14px 18px;margin:14px 0"><div style="font-size:11px;letter-spacing:.08em;text-transform:uppercase;color:#9fd3c2">Código de delegación</div>' +
    '<div style="font-size:26px;font-weight:800;letter-spacing:.04em">' + esc_(del.cod) + '</div><div style="font-size:12px;color:#cfe3ea">Para volver al portal: "Ya inscribí mi delegación", con este email y tu DNI como contraseña.</div></div>' +
    '<p style="margin-bottom:6px"><b>Disciplinas de la delegación</b></p><table style="border-collapse:collapse;width:100%;font-size:13px"><tr style="background:#f3f8f8"><th style="text-align:left;padding:6px 8px">Disciplina</th><th style="text-align:left;padding:6px 8px">ID</th><th style="padding:6px 8px">Part.</th></tr>' + filas + '</table>' +
    '<p>Se adjuntan <b>' + nAdj + ' imagen(es)</b>: listas de buena fe y acreditaciones, para mostrar en el celular el día del evento (también se pueden imprimir).</p>' +
    '<p><b>El día del evento:</b> presentar la lista (QR) en la mesa de cada disciplina. La mesa escanea el QR, registra el presentismo y habilita al equipo en el fixture. Cada participante con DNI y su acreditación.</p>' +
    '<p style="color:#5b7480">' + esc_(c.EVENTO_TEXTO || '') + '</p>' + (url ? '<p><a href="' + url + '" style="color:#1d4a6e;font-weight:700">Portal JUBU 2026</a></p>' : ''));
}
function urlPortal_() { try { return ScriptApp.getService().getUrl() || ''; } catch (e) { return ''; } }

/** Datos públicos: cronograma, fixture, podios y medallero. */
function apiPublico() {
  reset_();
  const cache = CacheService.getScriptCache();
  try { const hit = cache.get('publico'); if (hit) return JSON.parse(hit.indexOf('z:') === 0 ? Utilities.ungzip(Utilities.newBlob(Utilities.base64Decode(hit.slice(2)), 'application/x-gzip')).getDataAsString() : hit); } catch (e) {}
  const c = cfg_(), DISC = disc_();
  const slots = [];
  rows_('Cronograma').forEach(r => { if (!r.hora && !r.actividad) return; const s = slots.find(x => x[0] === r.hora); s ? s[1].push(r.actividad) : slots.push([r.hora, [r.actividad]]); });
  const res = {};
  rows_('Partidos').forEach(p => {
    const g = p.fase + (p.rama ? ' · ' + p.rama : '');
    res[p.disciplina] = res[p.disciplina] || [];
    let grp = res[p.disciplina].find(x => x[0] === g);
    if (!grp) { grp = [g, []]; res[p.disciplina].push(grp); }
    const fin = p.estado === 'Finalizado';
    const pd = fin && p.desempate ? ' (pasa ' + (p.desempate === p.lista_a ? p.equipo_a : p.equipo_b).replace(/ \(.*\)$/, '') + ')' : '';
    grp[1].push([p.equipo_a, p.equipo_b, fin ? p.tanto_a + ' - ' + p.tanto_b + pd : (p.hora ? p.hora + ' hs' : 'A definir'), !fin]);
  });
  const pod = {}, med = {};
  rows_('Podios').forEach(p => {
    (pod[p.disciplina] = pod[p.disciplina] || []).push({ rama: p.rama, puesto: p.puesto, nombre: p.nombre, inst: p.institucion });
    const m = med[p.institucion] = med[p.institucion] || [p.institucion, 0, 0, 0, []];
    if (p.puesto === '1') m[1]++; else if (p.puesto === '2') m[2]++; else if (p.puesto === '3') m[3]++;
    if (['1', '2', '3'].indexOf(p.puesto) >= 0) m[4].push([p.disciplina, p.rama, p.puesto, p.nombre]);
  });
  const medallero = Object.keys(med).map(k => med[k]).sort((a, b) => b[1] - a[1] || b[2] - a[2] || b[3] - a[3] || a[0].localeCompare(b[0]));
  const pun = {};
  if (sheet_('Puntajes')) rows_('Puntajes').forEach(r => {
    const t = r.ronda + (r.rama ? ' · ' + r.rama : ''), L = pun[r.disciplina] = pun[r.disciplina] || [];
    let g = L.find(x => x.titulo === t);
    if (!g) { g = { titulo: t, orden: r.orden, filas: [] }; L.push(g); }
    g.filas.push([r.nombre, r.institucion, r.puntaje]);
  });
  Object.keys(pun).forEach(k => pun[k].forEach(g => g.filas.sort((a, b) => (g.orden === 'asc' ? 1 : -1) * (num_(a[2]) - num_(b[2])))));
  const circ = sheet_('Circulares') ? rows_('Circulares').filter(r => r.titulo).map(r => ({ titulo: r.titulo, subtitulo: r.subtitulo, estado: r.estado, link: r.link, texto: r.texto })) : [];
  const out = { estado: c.CRONOGRAMA_ESTADO || 'Provisorio', crono: slots, circulares: circ, res: res, puntajes: pun, podios: pod, med: medallero,
    tipos: DISC.reduce((o, d) => (o[d.n] = d.tipo, o), {}), actualizado: Utilities.formatDate(new Date(), TZ, 'HH:mm') };
  guardarPublico_(cache, out);
  return out;
}

/* =====================================================================
   API ORGANIZACIÓN (Admin.html)
   ===================================================================== */

function adminLogin(pin) {
  reset_();
  pin = String(pin || '').trim();
  const cc = CacheService.getScriptCache(), malos = Number(cc.get('lim_pin_malo') || 0);
  if (malos >= 10) throw new Error('Demasiados PIN incorrectos seguidos. Esperá 5 minutos y volvé a probar.');
  const c = cfg_(), DISC = disc_();
  let ses = null;
  if (pin && pin === c.ADMIN_PIN) ses = { rol: 'admin', discs: DISC.map(d => d.n) };
  else if (pin && c.VIANDAS_PIN && pin === c.VIANDAS_PIN) ses = { rol: 'viandas', discs: [] };
  else { const ds = DISC.filter(d => d.pin && d.pin === pin); if (pin && ds.length) ses = { rol: 'mesa', discs: ds.map(d => d.n) }; }
  if (!ses) { cc.put('lim_pin_malo', String(malos + 1), 300); throw new Error('PIN incorrecto.'); }
  const token = firmarSesion_(ses);
  log_('admin_login', ses.rol + ' · ' + ses.discs.join(', '));
  return { token: token, rol: ses.rol, discs: DISC.filter(d => ses.discs.indexOf(d.n) >= 0).map(d => ({ n: d.n, tipo: d.tipo, ramas: d.ramas, min: d.min, max: d.max, formato: d.formato })) };
}
/* Sesión firmada: el token lleva rol, disciplinas y vencimiento, con una firma HMAC que solo el servidor puede generar.
   No depende de la caché (no se pierde) y dura 14 h. cerrarSesiones() invalida todas. */
const SES_HORAS = 14;
function secreto_() { let k = PROP.getProperty('TOKEN_SECRET'); if (!k) { k = Utilities.getUuid() + Utilities.getUuid(); PROP.setProperty('TOKEN_SECRET', k); } return k; }
function firma_(s) { return Utilities.base64EncodeWebSafe(Utilities.computeHmacSha256Signature(s, secreto_() + '|' + (PROP.getProperty('TOKEN_GEN') || '1'))).replace(/=+$/, ''); }
function firmarSesion_(ses) {
  const p = Utilities.base64EncodeWebSafe(JSON.stringify({ r: ses.rol, d: ses.discs, e: Date.now() + SES_HORAS * 3600e3 }), Utilities.Charset.UTF_8).replace(/=+$/, '');
  return p + '.' + firma_(p);
}
/** Cierra todas las sesiones de mesa y de administración (ejecutar desde el editor si se filtró un PIN). */
function cerrarSesiones() { PROP.setProperty('TOKEN_GEN', String(Number(PROP.getProperty('TOKEN_GEN') || '1') + 1)); return 'Listo: todas las mesas tienen que volver a ingresar con el PIN.'; }
function ses_(token, disc) {
  const t = String(token || ''), i = t.indexOf('.');
  if (i < 1 || firma_(t.slice(0, i)) !== t.slice(i + 1)) throw new Error('Sesión vencida. Volvé a ingresar con el PIN.');
  let o; try { o = JSON.parse(Utilities.newBlob(Utilities.base64DecodeWebSafe(t.slice(0, i) + '==='.slice((t.slice(0, i).length + 3) % 4))).getDataAsString()); } catch (e) { throw new Error('Sesión vencida. Volvé a ingresar con el PIN.'); }
  if (!o.e || Date.now() > o.e) throw new Error('Sesión vencida. Volvé a ingresar con el PIN.');
  const s = { rol: o.r, discs: o.d || [] };
  if (disc && s.discs.indexOf(disc) < 0) throw new Error('Tu PIN no habilita ' + disc + '.');
  return s;
}
function equipos_(listas) {
  const cnt = {}, tot = {};
  listas.forEach(l => { const k = l.disciplina + '|' + l.rama + '|' + l.institucion; tot[k] = (tot[k] || 0) + 1; });
  const out = {};
  listas.forEach(l => { const k = l.disciplina + '|' + l.rama + '|' + l.institucion; cnt[k] = (cnt[k] || 0) + 1; out[l.id] = l.institucion + (tot[k] > 1 ? ' (' + cnt[k] + ')' : ''); });
  return out;
}
function listaInfo_(l, parts, nombres) {
  const deps = parts.filter(p => p.lista === l.id);
  return { id: l.id, cod: l.cod, disc: l.disciplina, rama: l.rama, inst: l.institucion, equipo: nombres[l.id] || l.institucion,
    presente: l.presente, hora: l.hora_presente, cantidad: deps.length, presentes: deps.filter(p => p.presente === 'SI').length,
    deps: deps.map(p => ({ id: p.id, nombre: p.nombre, apellido: p.apellido, dni: p.dni, cond: p.condicion, presente: p.presente })) };
}

function adminBuscar(token, texto) {
  reset_();
  const s = ses_(token);
  texto = String(texto || '').trim().toUpperCase();
  const toks = texto.split(/[|\s]+/).map(t => t.trim()).filter(Boolean);
  if (!toks.length) throw new Error('Código no reconocido.');
  const listas = rows_('Listas'), parts = rows_('Participantes'), nombres = equipos_(listas), dels = rows_('Delegaciones');
  let l = null, foco = '';
  const tipoQr = toks[0] === 'LISTA' ? 'lista' : '';
  for (const t of toks) {
    if (t === 'LISTA') continue;
    l = listas.find(x => x.id === t);
    if (l) break;
    const p = parts.find(x => x.id === t);
    if (p) { l = listas.find(x => x.id === p.lista); foco = p.id; break; }
    const d = dels.find(x => x.jefe_id === t || (!tipoQr && x.cod === t));
    if (d) return { tipo: 'jefe', inst: d.institucion, nombre: d.jefe_nombre + ' ' + d.jefe_apellido, cod: d.cod };
    const o = rows_('Organizacion').find(x => x.id === t);
    if (o) return { tipo: 'org', nombre: o.nombre + ' ' + o.apellido, funcion: o.funcion, disc: o.disciplina };
  }
  const m = [toks.filter(t => t !== 'LISTA')[0] || texto];
  if (!l) throw new Error('No se encontró ' + m[0] + '.');
  if (s.discs.indexOf(l.disciplina) < 0) throw new Error('Esta lista es de ' + l.disciplina + ', no de tu mesa.');
  return { tipo: 'lista', foco: foco, lista: listaInfo_(l, parts, nombres) };
}

function adminPresente(token, listaId, presentes) {
  reset_();
  return conLock_(() => {
    const listas = rows_('Listas'), l = listas.find(x => x.id === listaId);
    if (!l) throw new Error('Lista inexistente.');
    const s = ses_(token, l.disciplina), set = new Set(presentes || []), d = disc_().find(x => x.n === l.disciplina) || { min: 1 };
    const parts = rows_('Participantes').filter(p => p.lista === listaId);
    const vals = {}; parts.forEach(p => vals[p._row] = set.has(p.id) ? 'SI' : 'NO'); setCol_('Participantes', 'presente', vals);
    const n = parts.filter(p => set.has(p.id)).length;
    const estado = n === 0 ? 'NO' : (n >= d.min ? 'SI' : 'INCOMPLETA');
    update_('Listas', l._row, { presente: estado, hora_presente: ahora_(), mesa: s.rol });
    log_('presentismo', listaId + ' · ' + n + '/' + parts.length + ' · ' + estado);
    planillaDeporte_(l.disciplina);
    return { estado: estado, presentes: n, min: d.min };
  });
}

/* ---------- Sistema suizo (ajedrez y otros individuales por enfrentamientos) ---------- */
const FASE_SUIZO = /^Ronda (\d+) de (\d+)$/;
function rondasSugeridas_(n) { return n <= 8 ? 3 : n <= 16 ? 4 : n <= 32 ? 5 : 6; }
/** Estado del suizo de una rama: ronda actual, total, pendientes y tabla (puntos 1 / ½ / 0, bye = 1; desempate Buchholz). */
function suizo_(disc, rama, comps, ps) {
  ps = ps.filter(p => FASE_SUIZO.test(p.fase));
  if (!ps.length) return null;
  const total = Number(FASE_SUIZO.exec(ps[0].fase)[2]), ronda = Math.max.apply(null, ps.map(p => Number(FASE_SUIZO.exec(p.fase)[1])));
  const T = {}, nom = id => (comps.find(c => c.id === id) || {}).nombre || id;
  const j = id => T[id] = T[id] || { id: id, nombre: nom(id), pts: 0, rivales: [], byes: 0, pj: 0, gan: 0 };
  ps.forEach(p => {
    if (!p.lista_a) return;
    if (!p.lista_b) { if (p.estado === 'Finalizado') { j(p.lista_a).pts += 1; T[p.lista_a].byes++; } return; }
    j(p.lista_a).rivales.push(p.lista_b); j(p.lista_b).rivales.push(p.lista_a);
    if (p.estado !== 'Finalizado') return;
    const a = num_(p.tanto_a), b = num_(p.tanto_b), w = ganador_(p);
    T[p.lista_a].pj++; T[p.lista_b].pj++;
    if (w) { T[w].pts += 1; T[w].gan++; } else if (a === b) { T[p.lista_a].pts += 0.5; T[p.lista_b].pts += 0.5; }
  });
  Object.values(T).forEach(x => x.buch = x.rivales.reduce((s, r) => s + (T[r] ? T[r].pts : 0), 0));
  const tabla = Object.values(T).sort((x, y) => y.pts - x.pts || y.buch - x.buch || y.gan - x.gan || x.nombre.localeCompare(y.nombre));
  const pend = ps.filter(p => Number(FASE_SUIZO.exec(p.fase)[1]) === ronda && p.lista_b && p.estado !== 'Finalizado').length;
  return { ronda: ronda, total: total, pendientes: pend, terminado: ronda === total && !pend, tabla: tabla.map(x => ({ id: x.id, nombre: x.nombre, pts: x.pts, buch: x.buch, pj: x.pj, byes: x.byes })) };
}
/** Genera la ronda siguiente del suizo. La primera vez define la cantidad de rondas. */
function adminSuizo(token, disc, rama, rondas) {
  reset_();
  return conLock_(() => {
    ses_(token, disc); rama = rama || '';
    const comps = comps_(disc, true).filter(c => c.rama === rama), todos = rows_('Partidos').filter(p => p.disciplina === disc && p.rama === rama);
    if (comps.length < 3) throw new Error('El suizo necesita al menos 3 competidores presentes (hay ' + comps.length + ').');
    const est = suizo_(disc, rama, comps, todos);
    if (!est && todos.some(p => !FASE_SUIZO.test(p.fase))) throw new Error('Esta rama ya tiene otro fixture. Borrá los partidos sin resultado antes de usar el suizo.');
    if (est && est.pendientes) throw new Error('Faltan ' + est.pendientes + ' resultado(s) de la ronda ' + est.ronda + '.');
    if (est && est.ronda >= est.total) throw new Error('El suizo ya jugó sus ' + est.total + ' rondas.');
    const total = est ? est.total : Math.max(1, Math.min(12, Number(rondas) || rondasSugeridas_(comps.length))), r = est ? est.ronda + 1 : 1;
    const pts = {}, riv = {}, byes = {};
    comps.forEach(c => { pts[c.id] = 0; riv[c.id] = new Set(); byes[c.id] = 0; });
    if (est) est.tabla.forEach(x => { if (x.id in pts) { pts[x.id] = x.pts; byes[x.id] = x.byes; } });
    todos.forEach(p => { if (p.lista_a && p.lista_b && riv[p.lista_a] && riv[p.lista_b]) { riv[p.lista_a].add(p.lista_b); riv[p.lista_b].add(p.lista_a); } });
    // orden: puntos (ronda 1: sorteo)
    let orden = comps.map(c => ({ id: c.id, inst: c.inst, nombre: c.nombre, s: Math.random() }));
    orden.sort((x, y) => pts[y.id] - pts[x.id] || (r === 1 ? x.s - y.s : (est.tabla.findIndex(t => t.id === x.id) - est.tabla.findIndex(t => t.id === y.id))));
    let bye = null;
    if (orden.length % 2) {   // descansa el de menos puntos que todavía no descansó
      for (let i = orden.length - 1; i >= 0; i--) if (!byes[orden[i].id]) { bye = orden[i]; break; }
      if (!bye) bye = orden[orden.length - 1];
      orden = orden.filter(x => x !== bye);
    }
    // emparejar: cada uno con el más cercano en la tabla, sin repetir rival (y evitando misma institución si se puede)
    const parejas = [];
    function arma(lista, permitir) {
      if (!lista.length) return true;
      const a = lista[0], resto = lista.slice(1);
      const cand = resto.map((b, k) => ({ b: b, k: k, pen: (a.inst === b.inst ? 1 : 0) })).sort((x, y) => x.pen - y.pen || x.k - y.k);
      for (const c of cand) {
        if (!permitir && riv[a.id].has(c.b.id)) continue;
        parejas.push([a, c.b]);
        if (arma(resto.filter(x => x !== c.b), permitir)) return true;
        parejas.pop();
      }
      return false;
    }
    let pasos = 0; const arma0 = arma; arma = (l, p) => { if (++pasos > 200000) return false; return arma0(l, p); };
    if (!arma(orden, false)) { parejas.length = 0; pasos = 0; arma(orden, true); }
    const usados = new Set(rows_('Partidos').map(p => p.id)), fase = 'Ronda ' + r + ' de ' + total, nuevos = [];
    parejas.forEach(([a, b], k) => { const ab = k % 2 ? [b, a] : [a, b];
      nuevos.push({ id: code_('P-', 5, usados), disciplina: disc, rama: rama, fase: fase, hora: '', lista_a: ab[0].id, equipo_a: ab[0].nombre, lista_b: ab[1].id, equipo_b: ab[1].nombre, tanto_a: '', tanto_b: '', estado: 'Pendiente', origen_a: '', origen_b: '', desempate: '' }); });
    if (bye) nuevos.push({ id: code_('P-', 5, usados), disciplina: disc, rama: rama, fase: fase, hora: '', lista_a: bye.id, equipo_a: bye.nombre, lista_b: '', equipo_b: 'Libre (descansa)', tanto_a: '1', tanto_b: '0', estado: 'Finalizado', origen_a: '', origen_b: '', desempate: '' });
    append_('Partidos', nuevos);
    limpiarCachePublico_();
    log_('suizo', disc + ' ' + rama + ' · ' + fase + ' · ' + nuevos.length + ' partidas');
    return { ronda: r, total: total, partidas: parejas.length, descansa: bye ? bye.nombre : '' };
  });
}

/** Agrupa partidos en llaves (componentes unidas por origen_a/origen_b). Devuelve {id: claveDeLlave}. */
function llaves_(ps) {
  const par = {}, f = x => par[x] === x ? x : (par[x] = f(par[x]));
  ps.forEach(p => par[p.id] = p.id);
  ps.forEach(p => [p.origen_a, p.origen_b].forEach(o => { if (o && par[o]) par[f(o)] = f(p.id); }));
  const out = {}; ps.forEach(p => out[p.id] = f(p.id)); return out;
}
const FASES_LLAVE = /(^|· )(Final|Semifinal|Cuartos de final|Octavos de final|16avos de final|32avos de final|Ronda de \d+)$/;
/** Puntos de tabla: ajedrez suma los puntos de cada partida (1, ½, 0); el resto 3 por victoria y 1 por empate. */
function puntosTabla_(disc, a, b) { return disc === 'Ajedrez' ? a : (a > b ? 3 : a === b ? 1 : 0); }
/** Ganador de un partido finalizado (lista o deportista). Empate: vale el desempate elegido por la mesa. */
function ganador_(p) {
  if (p.estado !== 'Finalizado') return '';
  const a = num_(p.tanto_a), b = num_(p.tanto_b);
  if (a > b) return p.lista_a; if (b > a) return p.lista_b;
  return p.desempate && (p.desempate === p.lista_a || p.desempate === p.lista_b) ? p.desempate : '';
}
function perdedor_(p) { const w = ganador_(p); return !w ? '' : w === p.lista_a ? p.lista_b : p.lista_a; }
function num_(v) { const n = Number(String(v == null ? '' : v).trim().replace('½', '0.5').replace(',', '.')); return isNaN(n) ? 0 : n; }
function nombrePart_(p) { return p.apellido + ', ' + p.nombre + ' (' + p.institucion + ')'; }
/** Competidores de una disciplina: listas (deportes de equipo) o deportistas (individuales). */
function comps_(disc, soloPresentes) {
  const d = disc_().find(x => x.n === disc) || { tipo: 'individual' };
  const todas = rows_('Listas'), nombres = equipos_(todas);
  if (d.tipo === 'equipo') return todas.filter(l => l.disciplina === disc && (!soloPresentes || l.presente === 'SI')).map(l => ({ id: l.id, nombre: nombres[l.id], inst: l.institucion, rama: l.rama }));
  return rows_('Participantes').filter(p => p.disciplina === disc && (!soloPresentes || p.presente === 'SI')).map(p => ({ id: p.id, nombre: nombrePart_(p), inst: p.institucion, rama: p.rama }));
}

function adminDisciplina(token, disc) {
  reset_();
  ses_(token, disc);
  const d = disc_().find(x => x.n === disc);
  const todas = rows_('Listas'), nombres = equipos_(todas), parts = rows_('Participantes');
  const listas = todas.filter(l => l.disciplina === disc).map(l => listaInfo_(l, parts, nombres));
  return {
    disc: d, listas: listas, comps: comps_(disc, true),
    partidos: rows_('Partidos').filter(p => p.disciplina === disc).map(p => ({ id: p.id, rama: p.rama, fase: p.fase, hora: p.hora, a: p.equipo_a, b: p.equipo_b, la: p.lista_a, lb: p.lista_b, ta: p.tanto_a, tb: p.tanto_b, estado: p.estado, de: p.desempate || '', llave: !!(p.origen_a || p.origen_b) || /(^|· )(Final|Semifinal|Cuartos de final|Octavos de final|16avos de final|32avos de final)$/.test(p.fase) })),
    suizo: (d.ramas.length ? d.ramas : ['']).reduce((o, r) => { const s = suizo_(disc, r, comps_(disc, false).filter(c => c.rama === r), rows_('Partidos').filter(p => p.disciplina === disc && p.rama === r)); if (s) o[r] = s; return o; }, {}),
    podio: rows_('Podios').filter(p => p.disciplina === disc).map(p => ({ rama: p.rama, puesto: p.puesto, lista: p.lista, participante: p.participante, nombre: p.nombre, inst: p.institucion })),
    puntajes: (sheet_('Puntajes') ? rows_('Puntajes') : []).filter(p => p.disciplina === disc).map(p => ({ rama: p.rama, ronda: p.ronda, orden: p.orden, ref: p.participante, nombre: p.nombre, inst: p.institucion, puntaje: p.puntaje }))
  };
}

/** Genera el fixture con los competidores presentes (equipos o deportistas). modo: 'todos' | 'grupos'. */
function adminGenerar(token, disc, rama, modo, tam) {
  reset_();
  return conLock_(() => {
    ses_(token, disc);
    rama = rama || '';
    const previos = rows_('Partidos').filter(p => p.disciplina === disc && p.rama === rama);
    if (previos.some(p => p.estado === 'Finalizado')) throw new Error('Ya hay resultados cargados en ' + disc + (rama ? ' ' + rama : '') + '. Usá "Llave manual" o "Partido suelto", o borrá esos partidos antes de regenerar.');
    const eq = comps_(disc, true).filter(c => c.rama === rama);
    if (eq.length < 2) throw new Error('Se necesitan al menos 2 competidores presentes (hay ' + eq.length + ').');
    for (let i = eq.length - 1; i > 0; i--) { const k = Math.floor(Math.random() * (i + 1)); const t = eq[i]; eq[i] = eq[k]; eq[k] = t; }
    const grupos = [];
    if (modo === 'grupos') {
      const n = Math.max(2, Number(tam) || 4);
      let g = Math.ceil(eq.length / n); while (g > 1 && Math.floor(eq.length / g) < 2) g--;
      const cap = Math.ceil(eq.length / g);
      for (let i = 0; i < g; i++) grupos.push(['Grupo ' + String.fromCharCode(65 + i), []]);
      // reparte parejo y evita que dos equipos de la misma institución caigan en el mismo grupo (si se puede)
      const cuenta = {}; eq.forEach(e => cuenta[e.inst] = (cuenta[e.inst] || 0) + 1);
      eq.slice().sort((x, y) => cuenta[y.inst] - cuenta[x.inst]).forEach(e => {
        const libres = grupos.filter(x => x[1].length < cap), sin = libres.filter(x => !x[1].some(o => o.inst === e.inst));
        const op = (sin.length ? sin : libres).sort((x, y) => x[1].length - y[1].length)[0]; op[1].push(e);
      });
    } else grupos.push(['Todos contra todos', eq]);
    remove_('Partidos', p => p.disciplina === disc && p.rama === rama);
    const usados = new Set(rows_('Partidos').map(p => p.id)), nuevos = [];
    grupos.forEach(([fase, ts]) => rr_(ts).forEach(([a, b]) => nuevos.push({ id: code_('P-', 5, usados), disciplina: disc, rama: rama, fase: fase, hora: '',
      lista_a: a.id, equipo_a: a.nombre, lista_b: b.id, equipo_b: b.nombre, tanto_a: '', tanto_b: '', estado: 'Pendiente', origen_a: '', origen_b: '' })));
    append_('Partidos', nuevos);
    limpiarCachePublico_();
    log_('fixture', disc + ' ' + rama + ' · ' + nuevos.length + ' partidos');
    return nuevos.length;
  });
}
/** Round robin (método del círculo): ordena las fechas para que nadie juegue dos seguidos si se puede. */
function rr_(ts) {
  const t = ts.slice();
  if (t.length % 2) t.push(null);
  const n = t.length, out = [];
  for (let r = 0; r < n - 1; r++) {
    for (let i = 0; i < n / 2; i++) { const a = t[i], b = t[n - 1 - i]; if (a && b) out.push(r % 2 ? [b, a] : [a, b]); }
    t.splice(1, 0, t.pop());
  }
  return out;
}

const RONDAS = ['Final', 'Semifinal', 'Cuartos de final', 'Octavos de final', '16avos de final', '32avos de final'];
/**
 * Llave de eliminación armada a mano. slots = IDs en orden (posición 1 vs 2, 3 vs 4, …); '' = libre (el rival pasa directo).
 * Cualquier cantidad de competidores: se completa hasta la potencia de 2 con lugares libres. Los ganadores avanzan solos.
 */
function adminLlave(token, disc, rama, slots, titulo) {
  reset_();
  return conLock_(() => {
    ses_(token, disc);
    rama = rama || '';
    slots = (slots || []).slice(0, 64).map(x => String(x || ''));
    const pool = comps_(disc, false), ids = slots.filter(Boolean);
    if (ids.length < 2) throw new Error('Elegí al menos 2 competidores.');
    if (new Set(ids).size !== ids.length) throw new Error('Hay un competidor repetido en la llave.');
    ids.forEach(id => { const c = pool.find(x => x.id === id); if (!c) throw new Error('Competidor inválido para ' + disc + '.'); if (c.rama !== rama) throw new Error(c.nombre + ' no es de la rama ' + (rama || 'única') + '.'); });
    let size = 2; while (size < slots.length) size *= 2;
    while (slots.length < size) slots.push('');
    for (let i = 0; i < size; i += 2) if (!slots[i] && !slots[i + 1] && ids.length > size / 2) throw new Error('El cruce ' + (i / 2 + 1) + ' quedó sin competidores: repartí los lugares libres para que nadie pase dos rondas sin jugar.');
    const pref0 = clean_(titulo, 40), esLlave = f => RONDAS.some(r => f === r || f === pref0 + ' · ' + r) || /^Ronda de \d+$/.test(f) || f.indexOf(pref0 + ' · Ronda de ') === 0;
    const previa = rows_('Partidos').filter(p => p.disciplina === disc && p.rama === rama && esLlave(p.fase));
    if (previa.some(p => p.estado === 'Finalizado')) throw new Error('Ya hay una llave' + (pref0 ? ' "' + pref0 + '"' : '') + ' con resultados en esta rama. Para armar otra, ponele otro nombre (ej.: Copa de plata).');
    if (previa.length) remove_('Partidos', p => p.disciplina === disc && p.rama === rama && esLlave(p.fase));
    const pref = pref0, usados = new Set(rows_('Partidos').map(p => p.id)), nuevos = [];
    let cur = slots.map(id => id ? { id: id, nombre: pool.find(c => c.id === id).nombre } : null);
    let ronda = Math.log2(size) - 1;
    while (cur.length > 1) {
      const fase = (pref ? pref + ' · ' : '') + (RONDAS[ronda] || ('Ronda de ' + cur.length)), next = [];
      let k = 0;
      for (let i = 0; i < cur.length; i += 2) {
        const a = cur[i], b = cur[i + 1];
        if (a && b) {
          const id = code_('P-', 5, usados); k++;
          nuevos.push({ id: id, disciplina: disc, rama: rama, fase: fase, hora: '', lista_a: a.id || '', equipo_a: a.nombre, lista_b: b.id || '', equipo_b: b.nombre,
            tanto_a: '', tanto_b: '', estado: 'Pendiente', origen_a: a.de || '', origen_b: b.de || '' });
          next.push({ id: '', nombre: 'Ganador ' + fase + ' ' + k, de: id });
        } else next.push(a || b || null);
      }
      cur = next; ronda--;
    }
    append_('Partidos', nuevos);
    limpiarCachePublico_();
    log_('llave', disc + ' ' + rama + ' · ' + nuevos.length + ' partidos');
    return nuevos.length;
  });
}

function adminBorrarPendientes(token, disc, rama) {
  reset_();
  return conLock_(() => {
    ses_(token, disc);
    const ps = rows_('Partidos').filter(p => p.disciplina === disc && p.rama === (rama || '')), L = llaves_(ps);
    const conRes = new Set(ps.filter(p => p.estado === 'Finalizado' || p.tanto_a || p.tanto_b).map(p => L[p.id]));
    const enLlave = p => !!(p.origen_a || p.origen_b || ps.some(x => x.origen_a === p.id || x.origen_b === p.id));
    // se borra lo pendiente; una llave que ya tiene resultados queda entera (si no, se rompe el cuadro)
    const borrar = new Set(ps.filter(p => p.estado !== 'Finalizado' && (!enLlave(p) || !conRes.has(L[p.id]))).map(p => p.id));
    const n = remove_('Partidos', p => borrar.has(p.id));
    limpiarCachePublico_();
    return n;
  });
}

/** Crea o edita un partido suelto. p = {id?, disc, rama, fase, hora, la, lb, a, b} (la/lb: lista o deportista) */
function adminPartido(token, p) {
  reset_();
  return conLock_(() => {
    ses_(token, p.disc);
    const pool = comps_(p.disc, false);
    const nom = (id, txt) => id ? ((pool.find(c => c.id === id) || {}).nombre || '') : clean_(txt, 60);
    if (p.la && p.la === p.lb) throw new Error('Elegiste el mismo competidor de los dos lados.');
    [p.la, p.lb].forEach(id => { if (id && !pool.some(c => c.id === id)) throw new Error('Competidor inválido para ' + p.disc + '.'); });
    const o = { disciplina: p.disc, rama: clean_(p.rama, 30), fase: clean_(p.fase, 60) || 'Partido', hora: clean_(p.hora, 10),
      lista_a: p.la || '', equipo_a: nom(p.la, p.a) || 'A definir', lista_b: p.lb || '', equipo_b: nom(p.lb, p.b) || 'A definir' };
    if (p.id) {
      const r = rows_('Partidos').find(x => x.id === p.id);
      if (!r) throw new Error('Partido inexistente.');
      update_('Partidos', r._row, o);
    } else {
      const usados = new Set(rows_('Partidos').map(x => x.id));
      o.id = code_('P-', 5, usados); o.tanto_a = ''; o.tanto_b = ''; o.estado = 'Pendiente'; o.origen_a = ''; o.origen_b = '';
      append_('Partidos', [o]);
    }
    limpiarCachePublico_();
    return true;
  });
}

function adminResultado(token, id, ta, tb, hora, desempate) {
  reset_();
  return conLock_(() => {
    const todos = rows_('Partidos'), r = todos.find(x => x.id === id);
    if (!r) throw new Error('Partido inexistente.');
    ses_(token, r.disciplina);
    const a = String(ta == null ? '' : ta).trim(), b = String(tb == null ? '' : tb).trim();
    const ok = v => /^\d{1,3}(?:[.,]5)?$|^½$/.test(v);
    if ((a && !ok(a)) || (b && !ok(b))) throw new Error('Resultado inválido: usá números (ej.: 21, 2, ½ o 0,5).');
    const fin = ok(a) && ok(b);
    if ((a || b) && (!r.lista_a || !r.lista_b)) throw new Error('Todavía no están definidos los dos competidores de este partido.');
    const de = fin && num_(a) === num_(b) && (desempate === r.lista_a || desempate === r.lista_b) ? desempate : '';
    const antes = ganador_(r), despues = ganador_({ estado: fin ? 'Finalizado' : '', tanto_a: a, tanto_b: b, lista_a: r.lista_a, lista_b: r.lista_b, desempate: de });
    const jugados = todos.filter(x => (x.origen_a === id || x.origen_b === id) && (x.estado === 'Finalizado' || x.tanto_a || x.tanto_b));
    if (antes !== despues && jugados.length) throw new Error('El partido siguiente (' + jugados[0].fase + ': ' + jugados[0].equipo_a + ' vs ' + jugados[0].equipo_b + ') ya tiene resultado. Borrá primero ese resultado para cambiar quién avanza.');
    const cambio = a !== r.tanto_a || b !== r.tanto_b || de !== (r.desempate || '');
    update_('Partidos', r._row, { tanto_a: a, tanto_b: b, hora: clean_(hora, 10), estado: fin ? 'Finalizado' : 'Pendiente', desempate: de });
    // avance automático en llaves
    const w = ganador_({ estado: fin ? 'Finalizado' : '', tanto_a: a, tanto_b: b, lista_a: r.lista_a, lista_b: r.lista_b, desempate: de });
    const gana = w ? { id: w, n: w === r.lista_a ? r.equipo_a : r.equipo_b } : null;
    const hermanos = todos.filter(x => x.disciplina === r.disciplina && x.rama === r.rama && x.fase === r.fase && (x.origen_a || x.origen_b || todos.some(y => y.origen_a === x.id || y.origen_b === x.id)) === (r.origen_a || r.origen_b || todos.some(y => y.origen_a === r.id || y.origen_b === r.id)));
    const lbl = 'Ganador ' + r.fase + ' ' + (hermanos.findIndex(x => x.id === r.id) + 1);
    todos.filter(x => x.origen_a === id || x.origen_b === id).forEach(x => {
      const o = {};
      if (x.origen_a === id) { o.lista_a = gana ? gana.id : ''; o.equipo_a = gana ? gana.n : lbl; }
      if (x.origen_b === id) { o.lista_b = gana ? gana.id : ''; o.equipo_b = gana ? gana.n : lbl; }
      update_('Partidos', x._row, o);
    });
    limpiarCachePublico_();
    log_('resultado', id + ' · ' + a + '-' + b);
    if (cambio) autoPodio_(r.disciplina, r.rama, true);
    return fin ? (gana || !todos.some(x => x.origen_a === id || x.origen_b === id) ? 'Finalizado' : 'Finalizado (empate: elegí quién gana por desempate para que avance)') : 'Pendiente';
  });
}

function adminBorrarPartido(token, id) {
  reset_();
  return conLock_(() => {
    const r = rows_('Partidos').find(x => x.id === id);
    if (!r) return false;
    ses_(token, r.disciplina);
    const todos = rows_('Partidos');
    if (r.origen_a || r.origen_b || todos.some(x => x.origen_a === id || x.origen_b === id)) throw new Error('Este partido es parte de una llave: no se puede borrar suelto. Usá "Borrar los que no tienen resultado" para rehacer la llave.');
    remove_('Partidos', x => x.id === id);
    if (r.estado === 'Finalizado') autoPodio_(r.disciplina, r.rama, true);
    limpiarCachePublico_();
    return true;
  });
}

/** Puntajes o resultados individuales por ronda. filas = [{ref:'JUBU26-…', puntaje:'8.5'}]; orden 'desc' (gana el mayor) o 'asc' (gana el menor, ej. tiempos). */
function adminPuntajes(token, disc, rama, ronda, orden, filas) {
  reset_();
  return conLock_(() => {
    ses_(token, disc);
    rama = rama || ''; ronda = clean_(ronda, 40) || 'Final'; orden = orden === 'asc' ? 'asc' : 'desc';
    const parts = rows_('Participantes'), out = [];
    (filas || []).forEach(f => {
      const p = parts.find(x => x.id === f.ref && x.disciplina === disc), v = clean_(f.puntaje, 12);
      if (p && v !== '' && (v === '–' || /\d/.test(v))) out.push({ disciplina: disc, rama: rama, ronda: ronda, orden: orden, participante: p.id, nombre: p.nombre + ' ' + p.apellido, institucion: p.institucion, puntaje: v });
    });
    remove_('Puntajes', r => r.disciplina === disc && r.rama === rama && r.ronda === ronda);
    append_('Puntajes', out);
    limpiarCachePublico_();
    log_('puntajes', disc + ' ' + rama + ' ' + ronda + ' · ' + out.length);
    autoPodio_(disc, rama, true);
    return out.length;
  });
}

/** Guarda el podio de una disciplina/rama. puestos = [{puesto:'1'|'2'|'3', ref:'LBF-…' o 'JUBU26-…'}] */
function adminPodio(token, disc, rama, puestos) {
  reset_();
  return conLock_(() => { ses_(token, disc); return guardarPodio_(disc, rama || '', puestos, 'manual'); });
}
function guardarPodio_(disc, rama, puestos, origen) {
  const todas = rows_('Listas'), nombres = equipos_(todas), parts = rows_('Participantes'), filas = [];
  (puestos || []).forEach(x => {
    if (!x || !x.ref || ['1', '2', '3'].indexOf(String(x.puesto)) < 0) return;
    const l = todas.find(t => t.id === x.ref), p = parts.find(t => t.id === x.ref);
    if (l && l.disciplina === disc) filas.push({ disciplina: disc, rama: rama, puesto: String(x.puesto), lista: l.id, participante: '', institucion: l.institucion, nombre: nombres[l.id] });
    else if (p && p.disciplina === disc) filas.push({ disciplina: disc, rama: rama, puesto: String(x.puesto), lista: p.lista, participante: p.id, institucion: p.institucion, nombre: p.nombre + ' ' + p.apellido });
  });
  remove_('Podios', r => r.disciplina === disc && r.rama === rama);
  append_('Podios', filas);
  limpiarCachePublico_();
  log_('podio', disc + ' ' + rama + ' · ' + filas.length + ' · ' + origen);
  return filas.length;
}
/**
 * Arma el podio solo a partir de los resultados. Devuelve la cantidad de puestos guardados (0 = todavía no se puede).
 * Llave: final → 1.º y 2.º; perdedores de semifinal → 3.º. Todos contra todos (una sola fase): tabla al terminar todos los partidos.
 * Puntajes: ranking de la ronda "Final" (las rondas previas no publican podio).
 */
function autoPodio_(disc, rama, limpiar) {
  const d = disc_().find(x => x.n === disc);
  if (!d) return 0;
  const n = autoPodioCalc_(d, disc, rama);
  if (!n && limpiar && rows_('Podios').some(r => r.disciplina === disc && r.rama === rama)) { remove_('Podios', r => r.disciplina === disc && r.rama === rama); limpiarCachePublico_(); log_('podio', disc + ' ' + rama + ' · retirado (resultados incompletos)'); }
  return n;
}
function autoPodioCalc_(d, disc, rama) {
  let puestos = [];
  if (d.formato === 'puntaje') {
    const pts = (sheet_('Puntajes') ? rows_('Puntajes') : []).filter(x => x.disciplina === disc && x.rama === rama);
    const rondas = [...new Set(pts.map(x => x.ronda))], ronda = rondas.indexOf('Final') >= 0 ? 'Final' : '';
    if (!ronda) return 0;
    const rk = pts.filter(x => x.ronda === ronda), asc = rk[0].orden === 'asc';
    if (rk.some(x => !/\d/.test(x.puntaje))) return 0;
    rk.sort((a, b) => (asc ? 1 : -1) * (num_(a.puntaje) - num_(b.puntaje)));
    puestos = rk.slice(0, 3).map((x, i) => ({ puesto: String(i + 1), ref: x.participante }));
  } else {
    const ps = rows_('Partidos').filter(x => x.disciplina === disc && x.rama === rama);
    const fin = p => !!ganador_(p), gan = ganador_, per = perdedor_;
    if (ps.some(p => FASE_SUIZO.test(p.fase))) {
      const sz = suizo_(disc, rama, comps_(disc, false).filter(c => c.rama === rama), ps);
      if (!sz || !sz.terminado) return 0;
      puestos = sz.tabla.slice(0, 3).map((x, i) => ({ puesto: String(i + 1), ref: x.id }));
      puestos = puestos.filter(x => x.ref);
      return puestos.length ? guardarPodio_(disc, rama, puestos, 'automático (suizo)') : 0;
    }
    const finales = ps.filter(p => /(^|· )Final$/.test(p.fase));
    if (finales.length) {
      // si hay varias llaves (ej. Copa de oro y Copa de plata) el podio sale de la más grande; a igualdad, la primera creada
      const L = llaves_(ps), tam = k => ps.filter(p => L[p.id] === k).length;
      const f = finales.slice().sort((x, y) => tam(L[y.id]) - tam(L[x.id]) || x._row - y._row)[0];
      if (!fin(f) || !f.lista_a || !f.lista_b) return 0;
      puestos = [{ puesto: '1', ref: gan(f) }, { puesto: '2', ref: per(f) }];
      ps.filter(p => L[p.id] === L[f.id] && /(^|· )Semifinal$/.test(p.fase) && fin(p)).forEach(p => puestos.push({ puesto: '3', ref: per(p) }));
    } else {
      if (!ps.length || new Set(ps.map(p => p.fase)).size !== 1 || ps.some(p => p.estado !== 'Finalizado')) return 0;
      const t = {};
      const s = (id, pts, a, b) => { if (!id) return; t[id] = t[id] || { id: id, pts: 0, dif: 0, af: 0 }; t[id].pts += pts; t[id].dif += a - b; t[id].af += a; };
      ps.forEach(p => { const a = num_(p.tanto_a), b = num_(p.tanto_b); s(p.lista_a, puntosTabla_(disc, a, b), a, b); s(p.lista_b, puntosTabla_(disc, b, a), b, a); });
      puestos = Object.values(t).sort((x, y) => y.pts - x.pts || y.dif - x.dif || y.af - x.af).slice(0, 3).map((x, i) => ({ puesto: String(i + 1), ref: x.id }));
    }
  }
  puestos = puestos.filter(x => x.ref);
  return puestos.length ? guardarPodio_(disc, rama, puestos, 'automático') : 0;
}

/** Pasa a los mejores N de una ronda a la ronda Final (quedan con puntaje pendiente "–"). */
function adminClasificar(token, disc, rama, deRonda, n) {
  reset_();
  return conLock_(() => {
    ses_(token, disc);
    rama = rama || ''; n = Math.max(1, Math.min(64, Number(n) || 0));
    const pts = rows_('Puntajes').filter(x => x.disciplina === disc && x.rama === rama && x.ronda === deRonda && /\d/.test(x.puntaje));
    if (!pts.length) throw new Error('No hay puntajes cargados en ' + deRonda + '.');
    if (deRonda === 'Final') throw new Error('Elegí una ronda anterior a la Final.');
    const asc = pts[0].orden === 'asc';
    pts.sort((a, b) => (asc ? 1 : -1) * (num_(a.puntaje) - num_(b.puntaje)));
    const sel = pts.slice(0, n);
    remove_('Puntajes', r => r.disciplina === disc && r.rama === rama && r.ronda === 'Final');
    append_('Puntajes', sel.map(x => ({ disciplina: disc, rama: rama, ronda: 'Final', orden: x.orden, participante: x.participante, nombre: x.nombre, institucion: x.institucion, puntaje: '–' })));
    remove_('Podios', r => r.disciplina === disc && r.rama === rama);
    limpiarCachePublico_();
    log_('clasificacion', disc + ' ' + rama + ' · ' + deRonda + ' → Final · ' + sel.length);
    return sel.length;
  });
}

/** Presentismo de un/a solo/a deportista (al escanear su acreditación). si=false lo deshace. No toca al resto de la lista. */
function adminPresenteUno(token, partId, si) {
  reset_();
  return conLock_(() => {
    const p = rows_('Participantes').find(x => x.id === partId);
    if (!p) throw new Error('Deportista inexistente.');
    const s = ses_(token, p.disciplina), l = rows_('Listas').find(x => x.id === p.lista), d = disc_().find(x => x.n === p.disciplina) || { min: 1 };
    update_('Participantes', p._row, { presente: si === false ? '' : 'SI' });
    const parts = rows_('Participantes').filter(x => x.lista === p.lista), n = parts.filter(x => x.presente === 'SI').length;
    const estado = n === 0 ? (parts.some(x => x.presente === 'NO') ? 'NO' : '') : (n >= d.min ? 'SI' : 'INCOMPLETA');
    update_('Listas', l._row, { presente: estado, hora_presente: estado ? ahora_() : '', mesa: s.rol });
    log_('presentismo', p.id + ' · ' + (si === false ? 'deshecho' : 'presente') + ' · lista ' + l.id + ' ' + n + '/' + parts.length);
    planillaDeporte_(p.disciplina);
    return { estado: estado, presentes: n, total: parts.length, min: d.min, nombre: p.nombre + ' ' + p.apellido, lista: l.id, disc: p.disciplina };
  });
}

/** Cambia el formato de una disciplina: 'puntaje' o 'partidos'. */
function adminFormato(token, disc, formato) {
  reset_();
  return conLock_(() => {
    ses_(token, disc);
    if (formato !== 'puntaje' && formato !== 'partidos') throw new Error('Formato inválido.');
    const r = rows_('Disciplinas').find(x => x.disciplina === disc);
    if (!r) throw new Error('Disciplina inexistente.');
    update_('Disciplinas', r._row, { formato: formato });
    log_('formato', disc + ' · ' + formato);
    return formato;
  });
}

/** Ejecuta una acción de mesa y devuelve también el estado actualizado de la disciplina (una sola llamada en vez de dos). */
function adminHacer(token, fn, args, disc) {
  reset_();
  reset_();
  const ACC = { adminPresente: adminPresente, adminPresenteUno: adminPresenteUno, adminDeshacerPresente: adminDeshacerPresente, adminResultado: adminResultado,
    adminPuntajes: adminPuntajes, adminLlave: adminLlave, adminGenerar: adminGenerar, adminBorrarPendientes: adminBorrarPendientes, adminPartido: adminPartido,
    adminBorrarPartido: adminBorrarPartido, adminPodio: adminPodio, adminClasificar: adminClasificar, adminFormato: adminFormato, adminSuizo: adminSuizo };
  if (!ACC[fn]) throw new Error('Acción no permitida.');
  _NORESET++;   // la acción y el estado comparten la misma lectura de la planilla
  try {
    const r = ACC[fn].apply(null, [token].concat(args || []));
    let est = null; try { if (disc) est = adminDisciplina(token, disc); } catch (e) {}
    return { r: r, est: est };
  } finally { _NORESET--; }
}

/* ---------- panel general (solo PIN general) ---------- */

function adminResumen(token) {
  reset_();
  const s = ses_(token);
  if (s.rol !== 'admin') throw new Error('Solo con el PIN general.');
  const dels = rows_('Delegaciones'), listas = rows_('Listas'), parts = rows_('Participantes'), nombres = equipos_(listas), fe = cfg_().FECHA_EVENTO;
  const PART = rows_('Partidos'), POD = rows_('Podios'), PUN = sheet_('Puntajes') ? rows_('Puntajes') : [];
  const porDisc = disc_().map(d => {
    const ls = listas.filter(l => l.disciplina === d.n), ps = parts.filter(p => p.disciplina === d.n);
    const pa = PART.filter(p => p.disciplina === d.n), ramas = d.ramas.length ? d.ramas : [''];
    return { n: d.n, tipo: d.tipo, formato: d.formato, listas: ls.length, listasPres: ls.filter(l => l.presente === 'SI').length, deportistas: ps.length, presentes: ps.filter(p => p.presente === 'SI').length,
      partidos: pa.length, partidosFin: pa.filter(p => p.estado === 'Finalizado').length, puntajes: PUN.filter(p => p.disciplina === d.n && /\d/.test(p.puntaje)).length,
      ramas: ramas.length, podios: ramas.filter(r => POD.some(p => p.disciplina === d.n && p.rama === r)).length };
  });
  return {
    kpi: { delegaciones: dels.length, listas: listas.length, deportistas: parts.length, presentes: parts.filter(p => p.presente === 'SI').length,
      instituciones: new Set(dels.map(d => d.institucion.toLowerCase())).size, pendientes: dels.filter(d => /^PENDIENTE/.test(d.mail_jefe)).length,
      viandas: rows_('Viandas').length, organizadores: rows_('Organizacion').length },
    porDisc: porDisc,
    delegaciones: dels.map(d => ({ cod: d.cod, fecha: d.fecha, inst: d.institucion,
      estado: /^ENVIADO/.test(d.mail_jefe) ? 'enviada' : (listas.filter(l => l.cod === d.cod).length && listas.filter(l => l.cod === d.cod).every(l => /^SI/.test(l.validada)) ? 'validada' : 'pendiente'), jefe: d.jefe_nombre + ' ' + d.jefe_apellido, dni: d.jefe_dni,
      email: d.email, tel: d.celular, cargo: d.cargo, mail: d.mail_jefe, reenviar: /^REENVIAR/.test(d.mail_jefe),
      listas: listas.filter(l => l.cod === d.cod).map(l => ({ id: l.id, disc: l.disciplina, rama: l.rama, equipo: nombres[l.id], presente: l.presente, fecha: l.fecha, validada: /^SI/.test(l.validada),
        deps: parts.filter(p => p.lista === l.id).map(p => ({ id: p.id, nombre: p.nombre, apellido: p.apellido, dni: p.dni, nac: p.nac, edad: edad_(p.nac, fe), email: p.email, cond: p.condicion, presente: p.presente, genero: p.genero, localidad: p.localidad })) })) })),
    correcciones: (sheet_('Correcciones') ? rows_('Correcciones') : []).map(r => ({ fila: r._row, fecha: r.fecha, cod: r.cod, inst: r.institucion, texto: r.texto, pendiente: r.estado === 'PENDIENTE' })),
    planilla: ss_().getUrl(), carpeta: urlDeportes_(), actualizado: Utilities.formatDate(new Date(), TZ, 'HH:mm')
  };
}

function adminReenviar(token, cod) {
  reset_();
  const s = ses_(token);
  if (s.rol !== 'admin') throw new Error('Solo con el PIN general.');
  return adminEnviar(token, cod);
}

/* ---------- informe cuantitativo y cualitativo (Google Docs) ---------- */

function franja_(e) { return e < 18 ? 'Menos de 18' : e <= 20 ? '18 a 20' : e <= 24 ? '21 a 24' : e <= 29 ? '25 a 29' : e <= 39 ? '30 a 39' : '40 o más'; }
const FRANJAS = ['18 a 20', '21 a 24', '25 a 29', '30 a 39', '40 o más'];
function contar_(arr, f) { const m = {}; arr.forEach(x => { const k = f(x) || 'Sin dato'; m[k] = (m[k] || 0) + 1; }); return Object.keys(m).map(k => [k, m[k]]).sort((a, b) => b[1] - a[1]); }
function pct_(n, t) { return t ? (Math.round(n * 1000 / t) / 10).toString().replace('.', ',') + ' %' : '0 %'; }

/** Genera el informe en Google Docs (carpeta Informes) y devuelve el link. Solo PIN general. */
function adminInforme(token) {
  reset_();
  const s = ses_(token);
  if (s.rol !== 'admin') throw new Error('Solo con el PIN general.');
  const c = cfg_(), fe = c.FECHA_EVENTO, dels = rows_('Delegaciones'), listas = rows_('Listas'), P = rows_('Participantes'), DISC = disc_();
  const pub = apiPublico(), T = P.length, pres = P.filter(p => p.presente === 'SI');
  const insts = contar_(P, p => p.institucion), gen = contar_(P, p => p.genero), cond = contar_(P, p => p.condicion), loc = contar_(P, p => p.localidad);
  const edades = P.map(p => edad_(p.nac, fe)).filter(e => e > 0).sort((a, b) => a - b);
  const prom = edades.length ? Math.round(edades.reduce((a, b) => a + b, 0) / edades.length * 10) / 10 : 0, med = edades.length ? edades[Math.floor(edades.length / 2)] : 0;
  const fr = FRANJAS.map(f => [f, P.filter(p => franja_(edad_(p.nac, fe)) === f).length]);
  const porDisc = DISC.map(d => { const ps = P.filter(p => p.disciplina === d.n); return [d.n, listas.filter(l => l.disciplina === d.n).length, ps.length, ps.filter(p => p.presente === 'SI').length,
    ps.filter(p => p.genero === 'Femenino').length, ps.filter(p => p.genero === 'Masculino').length]; });
  const conInsc = porDisc.filter(d => d[2] > 0).sort((a, b) => b[2] - a[2]), sinInsc = porDisc.filter(d => d[2] === 0).map(d => d[0]);
  const F = P.filter(p => p.genero === 'Femenino').length, M = P.filter(p => p.genero === 'Masculino').length;
  const fecha = Utilities.formatDate(new Date(), TZ, 'dd/MM/yyyy HH:mm');

  const doc = DocumentApp.create('Informe JUBU San Fernando 2026 · ' + Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH.mm')), b = doc.getBody();
  const H = (t, n) => b.appendParagraph(t).setHeading(n === 1 ? DocumentApp.ParagraphHeading.HEADING1 : n === 2 ? DocumentApp.ParagraphHeading.HEADING2 : DocumentApp.ParagraphHeading.TITLE);
  const Pf = t => b.appendParagraph(t);
  const Li = t => b.appendListItem(t);
  const Tb = (head, rows) => { if (!rows.length) { Pf('Sin datos registrados.'); return; } const t = b.appendTable([head].concat(rows.map(r => r.map(String)))); t.getRow(0).editAsText().setBold(true); return t; };

  H('Informe de los Juegos Universitarios Bonaerenses Urbanos · San Fernando 2026', 0);
  Pf('Sede: Parque del Bicentenario de la Independencia, Victoria, San Fernando. Fecha del evento: ' + fe.split('-').reverse().join('/') + '. Informe generado el ' + fecha + ' a partir de los registros del sistema de inscripción y organización.');

  H('1. Síntesis', 1);
  Pf('Se deja constancia de que los JUBU San Fernando 2026 registraron la inscripción de ' + T + ' deportistas pertenecientes a ' + insts.length + ' instituciones de educación superior, nucleados en ' + dels.length + ' delegaciones y ' + listas.length + ' listas de buena fe, en ' + conInsc.length + ' de las ' + DISC.length + ' disciplinas del programa.' +
    (pres.length ? ' El día del evento se registró la presencia de ' + pres.length + ' deportistas (' + pct_(pres.length, T) + ' de los inscriptos).' : ' A la fecha del informe no se registró presentismo.'));

  H('2. Participación por disciplina', 1);
  Tb(['Disciplina', 'Listas', 'Inscriptos', 'Presentes', '% asistencia', 'Mujeres', 'Varones'], porDisc.map(d => [d[0], d[1], d[2], d[3], pct_(d[3], d[2]), d[4], d[5]]));
  H('3. Instituciones participantes', 1);
  const medI = {}; pub.med.forEach(m => medI[m[0]] = m);
  Tb(['Institución', 'Inscriptos', '% del total', 'Disciplinas', 'Oro', 'Plata', 'Bronce'], insts.map(([n, k]) => { const m = medI[n] || [n, 0, 0, 0]; return [n, k, pct_(k, T), new Set(P.filter(p => p.institucion === n).map(p => p.disciplina)).size, m[1], m[2], m[3]]; }));
  H('4. Perfil de los inscriptos', 1);
  H('4.1 Género', 2); Tb(['Género', 'Cantidad', '%'], gen.map(([g, k]) => [g, k, pct_(k, T)]));
  H('4.2 Edad', 2); Pf('Edad promedio: ' + String(prom).replace('.', ',') + ' años · mediana: ' + med + ' · mínima: ' + (edades[0] || 0) + ' · máxima: ' + (edades[edades.length - 1] || 0) + '.');
  Tb(['Franja etaria', 'Cantidad', '%'], fr.map(([f, k]) => [f, k, pct_(k, T)]));
  H('4.3 Condición en la institución', 2); Tb(['Condición', 'Cantidad', '%'], cond.map(([g, k]) => [g, k, pct_(k, T)]));
  H('4.4 Localidad de residencia', 2); Tb(['Localidad', 'Cantidad', '%'], loc.slice(0, 20).map(([g, k]) => [g, k, pct_(k, T)]));
  H('5. Resultados', 1);
  H('5.1 Medallero', 2); Tb(['#', 'Institución', 'Oro', 'Plata', 'Bronce', 'Total'], pub.med.map((m, i) => [i + 1, m[0], m[1], m[2], m[3], m[1] + m[2] + m[3]]));
  H('5.2 Podios por disciplina', 2);
  const pods = []; Object.keys(pub.podios).forEach(d => pub.podios[d].slice().sort((x, y) => (x.rama || '').localeCompare(y.rama || '') || x.puesto - y.puesto).forEach(x => pods.push([d + (x.rama ? ' · ' + x.rama : ''), x.puesto + '.º', x.nombre, x.inst])));
  Tb(['Disciplina', 'Puesto', 'Equipo / deportista', 'Institución'], pods);

  H('6. Análisis cualitativo', 1);
  if (conInsc.length) Li('Mayor convocatoria: ' + conInsc.slice(0, 3).map(d => d[0] + ' (' + d[2] + ')').join(', ') + '. ' + (conInsc.length > 3 ? 'Menor convocatoria entre las disciplinas con inscriptos: ' + conInsc.slice(-2).map(d => d[0] + ' (' + d[2] + ')').join(', ') + '.' : ''));
  if (sinInsc.length) Li('Disciplinas sin inscriptos: ' + sinInsc.join(', ') + '. Se sugiere revisar la difusión específica o el formato de estas propuestas.');
  if (T) Li('Composición por género: ' + F + ' mujeres (' + pct_(F, T) + ') y ' + M + ' varones (' + pct_(M, T) + ')' + (Math.abs(F - M) / T < 0.15 ? ', con una distribución equilibrada.' : (F > M ? ', con predominio de participación femenina.' : ', con predominio de participación masculina.')));
  const femDisc = porDisc.filter(d => d[2] >= 3).map(d => [d[0], d[4] / d[2]]).sort((a, b) => b[1] - a[1]);
  if (femDisc.length > 1) Li('Mayor proporción de mujeres: ' + femDisc[0][0] + ' (' + pct_(femDisc[0][1], 1) + '). Menor: ' + femDisc[femDisc.length - 1][0] + ' (' + pct_(femDisc[femDisc.length - 1][1], 1) + ').');
  if (edades.length) { const top = fr.slice().sort((a, b) => b[1] - a[1])[0]; Li('Perfil etario: predomina la franja de ' + top[0] + ' años (' + pct_(top[1], T) + '), con una edad promedio de ' + String(prom).replace('.', ',') + ' años.'); }
  if (cond.length) Li('Condición predominante: ' + cond[0][0] + ' (' + pct_(cond[0][1], T) + ')' + (cond.length > 1 ? '; le sigue ' + cond[1][0] + ' (' + pct_(cond[1][1], T) + ').' : '.'));
  if (loc.length) Li('Alcance territorial: los inscriptos provienen de ' + loc.length + ' localidades; las principales son ' + loc.slice(0, 3).map(l => l[0] + ' (' + pct_(l[1], T) + ')').join(', ') + '.');
  if (insts.length) Li('Instituciones con mayor participación: ' + insts.slice(0, 3).map(i => i[0] + ' (' + i[1] + ')').join(', ') + '.');
  if (pres.length) { const aus = listas.filter(l => l.presente === 'NO' || l.presente === '').length, inc = listas.filter(l => l.presente === 'INCOMPLETA').length; Li('Asistencia: ' + pct_(pres.length, T) + ' de los inscriptos se presentó. Listas ausentes o sin registrar: ' + aus + '; listas incompletas: ' + inc + '.'); }
  if (pub.med.length) Li('Resultados: ' + pub.med[0][0] + ' encabeza el medallero con ' + pub.med[0][1] + ' oro(s), ' + pub.med[0][2] + ' plata(s) y ' + pub.med[0][3] + ' bronce(s).');
  H('7. Consideraciones de la organización', 1);
  Pf('[Completar: balance del evento, aspectos a mejorar, articulación interinstitucional y proyección para la próxima edición.]');

  doc.saveAndClose();
  try { DriveApp.getFileById(doc.getId()).moveTo(carpeta_(['Informes'], true)); } catch (e) {}
  log_('informe', doc.getUrl());
  return doc.getUrl();
}

/* ---------- validación y envío (PIN general) ---------- */

function soloAdmin_(token) { const s = ses_(token); if (s.rol !== 'admin') throw new Error('Solo con el PIN general.'); return s; }

function adminDelegacion(token, cod) {
  reset_();
  soloAdmin_(token);
  const d = delegacion_(clean_(cod, 20).toUpperCase());
  if (!d) throw new Error('Delegación inexistente.');
  return d;
}

/** Corrige datos del jefe/a y/o deportistas. cambios = {jefe?:{…}, deps?:[{id, nombre, apellido, dni, nac, email, cond, genero, localidad}]} */
function adminEditar(token, cod, cambios) {
  reset_();
  soloAdmin_(token);
  return conLock_(() => {
    cod = clean_(cod, 20).toUpperCase();
    const c = cfg_(), err = [], dr = rows_('Delegaciones').find(r => r.cod === cod);
    if (!dr) throw new Error('Delegación inexistente.');
    const listas = rows_('Listas').filter(l => l.cod === cod), parts = rows_('Participantes'), regla = (c.DNI_REPETIDO || 'NO_EN_MISMA_DISCIPLINA').toUpperCase();
    const invalidar = new Set();
    cambios = cambios || {};
    if (cambios.jefe) {
      const j = cambios.jefe, o = { institucion: clean_(j.inst), jefe_nombre: clean_(j.nombre, 60), jefe_apellido: clean_(j.apellido, 60), jefe_dni: dni_(j.dni),
        jefe_nac: clean_(j.nac, 10), cargo: clean_(j.cargo, 80), celular: clean_(j.tel, 30), email: clean_(j.email, 120).toLowerCase() };
      if (!o.institucion || !o.jefe_nombre || !o.jefe_apellido) err.push('Jefe/a: faltan datos.');
      if (!okDoc_(o.jefe_dni)) err.push('Jefe/a: DNI o pasaporte inválido.');
      if (edad_(o.jefe_nac, c.FECHA_EVENTO) < 18) err.push('Jefe/a: debe tener 18 años.');
      if (!okMail_(o.email)) err.push('Jefe/a: email inválido.');
      if (rows_('Delegaciones').some(r => r.cod !== cod && r.jefe_dni === o.jefe_dni)) err.push('Jefe/a: ese DNI ya es jefe/a de otra delegación.');
      if (!err.length) {
        update_('Delegaciones', dr._row, o);
        if (o.institucion !== dr.institucion) parts.filter(p => p.cod === cod).forEach(p => update_('Participantes', p._row, { institucion: o.institucion }));
        if (o.institucion !== dr.institucion) listas.forEach(l => update_('Listas', l._row, { institucion: o.institucion }));
        listas.forEach(l => invalidar.add(l.id));
      }
    }
    (cambios.deps || []).forEach((x, i) => {
      const p = parts.find(q => q.id === x.id && q.cod === cod);
      if (!p) { err.push('Deportista inexistente: ' + x.id); return; }
      const o = { nombre: clean_(x.nombre, 60), apellido: clean_(x.apellido, 60), dni: dni_(x.dni), nac: clean_(x.nac, 10), email: clean_(x.email, 120).toLowerCase(),
        condicion: CONDICIONES.indexOf(x.cond) >= 0 ? x.cond : '', genero: GENEROS.indexOf(x.genero) >= 0 ? x.genero : '', localidad: clean_(x.localidad, 80) };
      const q = (o.apellido || p.apellido) + ': ';
      if (!o.nombre || !o.apellido) err.push(q + 'falta nombre o apellido.');
      if (!okDoc_(o.dni)) err.push(q + 'DNI o pasaporte inválido.');
      if (edad_(o.nac, c.FECHA_EVENTO) < 18) err.push(q + 'debe tener 18 años.');
      if (!okMail_(o.email)) err.push(q + 'email inválido.');
      if (!o.condicion || !o.genero || !o.localidad) err.push(q + 'faltan condición, género o localidad.');
      const dup = parts.find(z => z.id !== p.id && z.dni === o.dni && (regla === 'NUNCA' || z.disciplina === p.disciplina));
      if (dup) err.push(q + 'el DNI ' + o.dni + ' ya está inscripto (' + dup.disciplina + ', ' + dup.institucion + ').');
      if (err.length) return;
      const cambio = Object.keys(o).some(k => String(o[k]) !== String(p[k]));
      if (cambio) { update_('Participantes', p._row, o); invalidar.add(p.lista); }
    });
    if (err.length) return { ok: false, errores: Array.from(new Set(err)).slice(0, 12) };
    listas.filter(l => invalidar.has(l.id)).forEach(l => update_('Listas', l._row, { validada: '', enviada: '' }));
    if (invalidar.size) { update_('Delegaciones', dr._row, { mail_jefe: /^(ENVIADO|REENVIAR)/.test(dr.mail_jefe) ? 'REENVIAR · corregida ' + ahora_() : '' }); Array.from(new Set(listas.filter(l => invalidar.has(l.id)).map(l => l.disciplina))).forEach(planillaDeporte_); }
    log_('edicion', cod + ' · listas a revalidar: ' + invalidar.size);
    return { ok: true, del: delegacion_(cod) };
  });
}

function adminQuitarParticipante(token, id) {
  reset_();
  soloAdmin_(token);
  return conLock_(() => {
    const p = rows_('Participantes').find(x => x.id === id);
    if (!p) throw new Error('Deportista inexistente.');
    const d = disc_().find(x => x.n === p.disciplina) || { min: 1 }, resto = rows_('Participantes').filter(x => x.lista === p.lista && x.id !== id);
    if (resto.length < d.min) throw new Error(p.disciplina + ' necesita al menos ' + d.min + ' participante(s). Para sacar toda la disciplina, borrá la lista en la planilla.');
    remove_('Participantes', x => x.id === id);
    const l = rows_('Listas').find(x => x.id === p.lista);
    if (l) update_('Listas', l._row, { cantidad: resto.length, validada: '', enviada: '' });
    const dr = rows_('Delegaciones').find(r => r.cod === p.cod);
    if (dr) update_('Delegaciones', dr._row, { mail_jefe: /^(ENVIADO|REENVIAR)/.test(dr.mail_jefe) ? 'REENVIAR · corregida ' + ahora_() : '' });
    planillaDeporte_(p.disciplina);
    return { ok: true, del: delegacion_(p.cod) };
  });
}

/** El navegador del admin genera las imágenes validadas y las sube acá. */
function adminSubirImagen(token, cod, id, dataUrl) {
  reset_();
  soloAdmin_(token);
  const del = delegacion_(clean_(cod, 20).toUpperCase()), d = del && destino_(del, id);
  if (!d) throw new Error('Imagen no corresponde a la delegación.');
  const m = /^data:image\/(jpeg|png);base64,(.+)$/.exec(String(dataUrl || ''));
  if (!m || m[2].length > 4e6) throw new Error('Imagen inválida.');
  return guardarImagen_(d, id, m);
}

/** Marca la delegación como validada (todas sus disciplinas). Requiere que estén las imágenes generadas. */
function adminValidar(token, cod) {
  reset_();
  soloAdmin_(token);
  return conLock_(() => {
    cod = clean_(cod, 20).toUpperCase();
    const del = delegacion_(cod);
    if (!del) throw new Error('Delegación inexistente.');
    const faltan = [del.jefe.id].concat(del.listas.map(l => l.id), ...del.listas.map(l => l.deps.map(p => p.id))).filter(id => !imagen_(del, id, 'x'));
    if (faltan.length) throw new Error('Faltan ' + faltan.length + ' imágenes. Volvé a tocar "Validar".');
    const f = 'SI ' + ahora_();
    rows_('Listas').filter(l => l.cod === cod).forEach(l => update_('Listas', l._row, { validada: f }));
    const dr = rows_('Delegaciones').find(r => r.cod === cod);
    if (dr && !/^ENVIADO/.test(dr.mail_jefe)) update_('Delegaciones', dr._row, { mail_jefe: '' });
    log_('validacion', cod);
    return { ok: true, del: delegacion_(cod) };
  });
}

/** Envía al jefe/a todas las acreditaciones y listas (solo si todas sus disciplinas están validadas). */
function adminEnviar(token, cod) {
  reset_();
  soloAdmin_(token);
  cod = clean_(cod, 20).toUpperCase();
  const del = delegacion_(cod);
  if (!del) throw new Error('Delegación inexistente.');
  if (!del.listas.length || del.listas.some(l => !l.validada)) throw new Error('Validá todas las disciplinas de ' + cod + ' antes de enviar.');
  return enviarJefe_(cod, null);
}

/** Envía a todas las delegaciones validadas que todavía no recibieron el mail. */
function adminEnviarTodas(token) {
  reset_();
  soloAdmin_(token);
  const out = { enviadas: 0, pendientes: [] };
  rows_('Delegaciones').forEach(d => {
    if (/^ENVIADO/.test(d.mail_jefe)) return;
    const del = delegacion_(d.cod);
    if (!del.listas.length || del.listas.some(l => !l.validada)) { out.pendientes.push(d.cod); return; }
    try { enviarJefe_(d.cod, null); out.enviadas++; } catch (e) { out.pendientes.push(d.cod + ' (' + e.message + ')'); }
  });
  return out;
}

/* ---------- links de mesa, cierre de inscripción, recordatorio, PDF imprimible ---------- */

function setGeneral_(clave, valor) {
  const r = rows_('General').find(x => x.clave === clave);
  if (r) update_('General', r._row, { valor: valor }); else append_('General', [{ clave: clave, valor: valor, nota: '' }]);
}

/** Disciplinas con su PIN y links directos para mandar a cada mesa. */
function adminMesas(token) {
  reset_();
  soloAdmin_(token);
  const c = cfg_(), gas = urlPortal_();
  return { gas: gas, panel: c.PANEL_MESAS_URL || '', mesas: disc_().map(d => ({ n: d.n, pin: d.pin })), viandas: c.VIANDAS_PIN || '' };
}

/** Abre o cierra la inscripción y, opcionalmente, cambia la fecha de cierre (AAAA-MM-DD HH:MM). */
function adminInscripcion(token, abierta, cierre) {
  reset_();
  soloAdmin_(token);
  if (abierta !== null && abierta !== undefined) setGeneral_('INSCRIPCION_ABIERTA', abierta ? 'SI' : 'NO');
  if (cierre) {
    if (!/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}$/.test(cierre)) throw new Error('Fecha de cierre inválida (AAAA-MM-DD HH:MM).');
    setGeneral_('CIERRE', cierre);
    try { programarRecordatorio_(); } catch (e) {}
  }
  log_('inscripcion_estado', (abierta ? 'abierta' : 'cerrada') + ' · ' + (cierre || ''));
  CacheService.getScriptCache().remove('cfg');
  const c = cfg_();
  return { abierta: abierta_(c), flag: c.INSCRIPCION_ABIERTA, cierre: c.CIERRE };
}

function fechaCierre_(c) {
  const m = /^(\d{4})-(\d{2})-(\d{2})(?:\s+(\d{1,2}):(\d{2}))?/.exec(c.CIERRE || '');
  return m ? new Date(m[1] + '-' + m[2] + '-' + m[3] + 'T' + ('0' + (m[4] || '23')).slice(-2) + ':' + (m[5] || '59') + ':00-03:00') : null;
}
/** Programa el mail de recordatorio 48 h antes del cierre (se llama desde setup y al cambiar la fecha). */
function programarRecordatorio_() {
  ScriptApp.getProjectTriggers().forEach(t => { if (t.getHandlerFunction() === 'recordatorioCierre') ScriptApp.deleteTrigger(t); });
  const f = fechaCierre_(cfg_());
  if (!f) return 'sin fecha';
  const at = new Date(f.getTime() - 48 * 3600e3);
  if (at <= new Date()) return 'fuera de plazo';
  ScriptApp.newTrigger('recordatorioCierre').timeBased().at(at).create();
  return 'programado ' + Utilities.formatDate(at, TZ, 'dd/MM HH:mm');
}
/** Mail a cada jefe/a: la inscripción cierra en 48 h, con el resumen de lo cargado. */
function recordatorioCierre() {
  reset_();
  const c = cfg_();
  if (!abierta_(c) || (c.RECORDATORIO || 'SI').toUpperCase() !== 'SI') return 0;
  let n = 0;
  rows_('Delegaciones').forEach(d => {
    if (MailApp.getRemainingDailyQuota() < 1) return;
    const del = delegacion_(d.cod);
    MailApp.sendEmail({ to: del.jefe.email, name: c.NOMBRE_REMITENTE || 'JUBU 2026', replyTo: Session.getEffectiveUser().getEmail(),
      subject: 'JUBU San Fernando 2026 · La inscripción cierra en 48 horas', htmlBody: mailRecordatorio_(del, c) });
    n++;
  });
  log_('recordatorio', n + ' mails');
  return n;
}
function mailRecordatorio_(del, c) {
  const filas = del.listas.map(l => '<li>' + esc_(l.disc + (l.rama ? ' · ' + l.rama : '')) + ' · ' + l.deps.length + ' deportista(s)</li>').join('');
  return marco_('La inscripción cierra en 48 horas',
    '<p>Hola ' + esc_(del.jefe.nombre) + ', la inscripción a los JUBU cierra el <b>' + esc_((c.CIERRE || '').replace(/^(\d{4})-(\d{2})-(\d{2})/, '$3/$2/$1')) + ' hs</b>.</p>' +
    '<p>Delegación <b>' + esc_(del.cod) + '</b> · ' + esc_(del.inst) + ':</p><ul>' + filas + '</ul>' +
    '<p>Si te falta sumar alguna disciplina, entrá al portal → "Ya inscribí mi delegación" con este email y tu DNI.</p>' +
    (urlPortal_() ? '<p><a href="' + urlPortal_() + '" style="color:#1d4a6e;font-weight:700">Portal JUBU 2026</a></p>' : ''));
}

/** PDF imprimible (acreditaciones 4 por hoja + listas), generado en el navegador del admin al validar. */
function adminSubirPdf(token, cod, dataUrl) {
  reset_();
  soloAdmin_(token);
  cod = clean_(cod, 20).toUpperCase();
  if (!delegacion_(cod)) throw new Error('Delegación inexistente.');
  const m = /^data:application\/pdf;base64,(.+)$/.exec(String(dataUrl || '').replace(/^data:application\/pdf;filename=[^;]*;/, 'data:application/pdf;'));
  if (!m || m[1].length > 30e6) throw new Error('PDF inválido.');
  const f = conLock_(() => carpeta_(['Imprimibles'], true));
  archivos_(f, cod).forEach(x => x.setTrashed(true));
  f.createFile(Utilities.newBlob(Utilities.base64Decode(m[1]), 'application/pdf', cod + ' · Acreditaciones y listas para imprimir.pdf'));
  return true;
}
function pdfDelegacion_(cod) {
  const f = carpeta_(['Imprimibles'], false), fs = f ? archivos_(f, cod) : [];
  return fs.length ? fs[0].getBlob().setName('JUBU2026_' + cod + '_para_imprimir.pdf') : null;
}

/* ---------- correcciones y limpieza ---------- */

/** Deja una lista "sin registrar" (deshace el presentismo de la lista y de sus deportistas). */
function adminDeshacerPresente(token, listaId) {
  reset_();
  return conLock_(() => {
    const l = rows_('Listas').find(x => x.id === listaId);
    if (!l) throw new Error('Lista inexistente.');
    ses_(token, l.disciplina);
    rows_('Participantes').filter(p => p.lista === listaId).forEach(p => update_('Participantes', p._row, { presente: '' }));
    update_('Listas', l._row, { presente: '', hora_presente: '', mesa: '' });
    log_('presentismo_deshecho', listaId);
    planillaDeporte_(l.disciplina);
    return true;
  });
}

/**
 * BORRA TODOS LOS DATOS DE PRUEBA: inscripciones, presentismo, fixture, resultados, podios, puntajes,
 * imágenes, PDFs, informes y planillas por deporte. Conserva la configuración (General, Disciplinas con sus PIN,
 * Cronograma, Circulares). Ejecutar desde el editor: primero con CONFIRMAR = false para ver qué borra.
 */
function borrarDatosDePrueba() {
  reset_();
  const CONFIRMAR = false;   // ← cambiar a true para borrar de verdad
  const hojas = ['Delegaciones', 'Listas', 'Participantes', 'Partidos', 'Podios', 'Puntajes'];
  const resumen = hojas.map(n => n + ': ' + (sheet_(n) ? rows_(n).length : 0) + ' filas');
  const raiz = DriveApp.getFolderById(PROP.getProperty('FOLDER_ID')), carpetas = ['Imagenes', 'Deportes', 'Jefes de delegación', 'Imprimibles', 'Informes'];
  carpetas.forEach(n => { const it = raiz.getFoldersByName(n); if (it.hasNext()) resumen.push('Carpeta ' + n); });
  if (!CONFIRMAR) { const m = 'SIMULACIÓN (no se borró nada). Se borraría:\n' + resumen.join('\n') + '\n\nPara borrar: cambiá CONFIRMAR a true, guardá y ejecutá de nuevo.'; Logger.log(m); return m; }
  conLock_(() => {
    hojas.forEach(n => { const sh = sheet_(n); if (sh && sh.getLastRow() > 1) sh.getRange(2, 1, sh.getLastRow() - 1, HOJAS[n].length).clearContent(); });
    carpetas.forEach(n => { const it = raiz.getFoldersByName(n); while (it.hasNext()) it.next().setTrashed(true); });
    const props = PROP.getProperties();
    Object.keys(props).forEach(k => { if (/^F\||^PL\||^URL\||^PL_SUCIAS$/.test(k)) PROP.deleteProperty(k); });
    reset_();
    const img = raiz.createFolder('Imagenes'); PROP.setProperty('IMG_FOLDER_ID', img.getId());
    CacheService.getScriptCache().remove('publico');
  });
  log_('limpieza', 'datos de prueba borrados');
  const m = 'Listo: se borraron los datos de prueba (quedan en la papelera de Drive por 30 días). La configuración y los PIN se mantienen.';
  Logger.log(m); return m;
}

/** El deportista ve su propia acreditación (con DNI + mail), solo si su disciplina ya fue validada. */
function apiMiAcreditacion(dni, email) {
  reset_();
  dni = dni_(dni); email = clean_(email, 120).toLowerCase();
  limite_('acred_' + dni, 15, 3600);
  const ps = rows_('Participantes').filter(p => p.dni === dni && p.email.toLowerCase() === email);
  if (!ps.length) return { ok: false, error: 'No encontramos una inscripción con ese DNI y mail. Usá el mail que cargó tu jefe/a de delegación.' };
  const listas = rows_('Listas'), val = ps.filter(p => { const l = listas.find(x => x.id === p.lista); return l && /^SI/.test(l.validada); });
  if (!val.length) return { ok: false, error: 'Te encontramos: tu inscripción está en revisión por la organización. Cuando la validen vas a poder descargar tu acreditación acá (tu jefe/a de delegación también te avisa).' };
  return { ok: true, acred: val.map(p => ({ id: p.id, nombre: p.nombre, apellido: p.apellido, dni: p.dni, cond: p.condicion, disc: p.disciplina, rama: p.rama, inst: p.institucion })) };
}
